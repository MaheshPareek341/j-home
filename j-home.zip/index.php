<?php include_once "header.php" ?>
            <!-- site__body -->
            <div class="site__body"><!-- page -->
                <div class="page"><!-- page__body -->

                    <div class="page__body"><!-- block-slider -->
                        <div class="block block-slider block-slider--featured">
                            <div class="">
                                <div class="slider slider--with-dots">
                                    <div class="owl-carousel">
                                        <!--<a href="#shop-left-sidebar.html" class="pt-lg-5 mt-lg-5">-->
                                        <!--    <picture>-->
                                        <!--        <source media="(min-width: 768px)"-->
                                        <!--            srcset="images/slides/slide1_.jpg, images/slides/slide1_@2x.jpg 2x">-->
                                        <!--        <source media="(max-width: 767px)"-->
                                        <!--            srcset="images/slides/slide1_-portrait.jpg, images/slides/slide1_-portrait@2x.jpg 2x">-->
                                        <!--            <img src="images/slides/slide1_.jpg" alt="">-->
                                        <!--    </picture>-->
                                        <!--</a>-->
                                        <a href="#shop-left-sidebar.html">
                                            <picture>
                                                <img src="images/slides/slide02.jpg" alt="">
                                            </picture>
                                        </a>
                                        <a href="#shop-left-sidebar.html">
                                            <picture>
                                                <!--<source media="(min-width: 768px)"-->
                                                <!--    srcset="images/slides/slide03.jpg, images/slides/slide03@2x.jpg 2x">-->
                                                <!--<source media="(max-width: 767px)"-->
                                                <!--    srcset="images/slides/slide03-portrait.jpg, images/slides/slide03-portrait@2x.jpg 2x">-->
                                                <img src="images/slides/slide03.jpg" alt="">
                                            </picture>
                                        </a>
                                        <a href="#shop-left-sidebar.html">
                                            <picture>
                                                <!--<source media="(min-width: 768px)"-->
                                                <!--    srcset="images/slides/slide05.jpg, images/slides/slide05@2x.jpg 2x">-->
                                                <!--<source media="(max-width: 767px)"-->
                                                <!--    srcset="images/slides/slide05-portrait.jpg, images/slides/slide05-portrait@2x.jpg 2x">-->
                                                <img src="images/slides/slide05.jpg" alt="">
                                            </picture>
                                        </a>
                                        <a href="#shop-left-sidebar.html">
                                            <picture>
                                                <!--<source media="(min-width: 768px)"-->
                                                <!--    srcset="images/slides/slide04.jpg, images/slides/slide04@2x.jpg 2x">-->
                                                <!--<source media="(max-width: 767px)"-->
                                                <!--    srcset="images/slides/slide04-portrait.jpg, images/slides/slide04-portrait@2x.jpg 2x">-->
                                                <img src="images/slides/slide04.jpg" alt="">
                                            </picture>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- block-slider / end -->
                        
                        <div id="products"></div>
                        <!-- block-products-carousel -->
                        <div class="block block-products-carousel" >
                            <div class="container container--max--xl">
                                <div class="block__title">
                                    <h2 class="decor-header decor-header--align--center">CATEGORIES</h2>
                                </div>
                                <div class="block-products-carousel__slider slider slider--with-arrows">
                                    <div class="row">
                                        <div class="col-md-4">
                                          
                                            <div class="product-card__image"><a href="#shop-left-sidebar.html"><img
                                                       
                                                        src="images/products/product10-1.jpg" alt=""></a></div>
                                            <div class="product-card__info">
                                                <div class="product-card__name" style="text-align:center"><a href="#">Bedroom</a></div>
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Wooden-->
                                                <!--        Closet</a>-->
                                                <!--</div>-->
                                                
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                           
                                            <div class="product-card__image">
                                                <a href="#shop-left-sidebar.html">
                                                    <img src="images/products/product8-1.jpg" alt=""></a></div>
                                            <div class="product-card__info">
                                                <div class="product-card__name" style="text-align:center"><a href="#">Dining</a></div>
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Monero-->
                                                <!--        Chair</a>-->
                                                <!--</div>-->
                                               
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                           
                                            <div class="product-card__image"><a href="#shop-left-sidebar.html"><img
                                                        
                                                        src="images/products/product7-1.jpg" alt=""></a></div>
                                            <div class="product-card__info">
                                                <div class="product-card__name" style="text-align:center"><a href="#">Occasional</a></div>
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Shoe-->
                                                <!--        Cabinet</a>-->
                                                <!--</div>-->
                                            </div>
                                        </div>
                                      
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- block-products-carousel / end -->
                        
                        <!-- block-products-carousel -->
                        <div id="catalogue"></div>
                        <div class="block block-products-carousel">
                            <div class="container container--max--xl">
                                <div class="block__title">
                                    <h2 class="decor-header decor-header--align--center protest-guerrilla-regular">CATALOGUES</h2>
                                </div>
                                <div class="block-products-carousel__slider slider slider--with-arrows">
                                    <div class="row">
                                        <div class="col-md-4">
                                           
                                            <div class="product-card__image"><a href="#shop-left-sidebar.html"><img
                                                        
                                                        src="images/products/product6-1.jpg" alt=""></a></div>
                                            <div class="product-card__info">
                                                <div class="product-card__name" style="text-align:center"><a href="#">Bedroom</a></div>
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Round-->
                                                <!--        Stool</a>-->
                                                <!--</div>-->
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4">
                                           
                                            <div class="product-card__image"><a href="#shop-left-sidebar.html"><img
                                                        
                                                        src="images/products/product13-1.jpg" alt=""></a></div>
                                            <div class="product-card__info">
                                                <div class="product-card__name" style="text-align:center"><a href="#">Dining</a></div>
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Fabric-->
                                                <!--        Chair</a>-->
                                                <!--</div>-->
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                           
                                            <div class="product-card__image"><a href="#shop-left-sidebar.html"><img
                                                     
                                                        src="images/products/product2-1.jpg" alt=""></a></div>
                                            <div class="product-card__info">
                                                <div class="product-card__name" style="text-align:center"><a href="#">Occasional</a></div>
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Wooden-->
                                                <!--        Stool</a>-->
                                                <!--</div>-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- block-products-carousel / end -->
                        
                        
                         <!-- block-products-carousel -->
                        <!--<div class="block block-products-carousel">-->
                        <!--    <div class="container container--max--xl">-->
                        <!--        <div class="block__title">-->
                        <!--            <h2 class="decor-header decor-header--align--center">LATEST COLLECTIONS</h2>-->
                        <!--        </div>-->
                        <!--        <div class="block-products-carousel__slider slider slider--with-arrows">-->
                        <!--            <div class="row">-->
                        <!--                   <div class="col-md-4">-->
                                           
                        <!--                    <div class="product-card__image"><a href="#shop-left-sidebar.html"><img-->
                                                       
                        <!--                                src="images/products/product10-1.jpg" alt=""></a></div>-->
                        <!--                    <div class="product-card__info">-->
                        <!--                        <div class="product-card__name" style="text-align:center"><a href="#">Bedroom </a></div>-->
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Fabric-->
                                                <!--        Chair</a>-->
                                                <!--</div>-->
                        <!--                    </div>-->
                        <!--                </div>-->
                        <!--                <div class="col-md-4">-->
                                           
                        <!--                    <div class="product-card__image"><a href="#shop-left-sidebar.html"><img-->
                                                       
                        <!--                                src="images/products/product8-1.jpg" alt=""></a></div>-->
                        <!--                    <div class="product-card__info">-->
                        <!--                        <div class="product-card__name" style="text-align:center"><a href="#">Dining</a></div>-->
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Round-->
                                                <!--        Stool</a>-->
                                                <!--</div>-->
                        <!--                    </div>-->
                        <!--                </div>-->
                                        
                                     
                        <!--                <div class="col-md-4">-->
                        <!--                    <div class="product-card__image"><a href="#shop-left-sidebar.html"><img-->
                                                       
                        <!--                                src="images/products/product12-1.jpg" alt=""></a></div>-->
                        <!--                    <div class="product-card__info">-->
                        <!--                        <div class="product-card__name" style="text-align:center"><a href="#">Occasional</a></div>-->
                                                <!--<div class="product-card__name"><a href="#shop-left-sidebar.html">Wooden-->
                                                <!--        Stool</a>-->
                                                <!--</div>-->
                        <!--                    </div>-->
                        <!--                </div>-->
                        <!--            </div>-->
                        <!--        </div>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <!-- block-products-carousel / end -->
                        <!-- block-collections / end -->
                    </div>
                    <!-- page__body / end -->
                </div>
                <!-- page / end -->
            </div>
            <!-- site__body / end -->
            <!-- site__footer -->
<?php include_once "footer.php" ?>
           