<?php

class ContactController
{
    public function index()
    {
        // Show contact form
        include __DIR__ . '/../views/contact/index.php';
    }

    public function submit()
    {
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = isset($_POST['name']) ? trim($_POST['name']) : '';
            $email = isset($_POST['email']) ? trim($_POST['email']) : '';
            $message = isset($_POST['message']) ? trim($_POST['message']) : '';

            // Basic validation
            $errors = [];
            if (empty($name)) $errors[] = 'Name is required.';
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
            if (empty($message)) $errors[] = 'Message is required.';

            if (empty($errors)) {
                // Process the contact form (e.g., send email or save to database)
                // mail($email, "Contact Form Submission", $message);

                $success = "Thank you for contacting us!";
                include __DIR__ . '/../views/contact/success.php';
            } else {
                include __DIR__ . '/../views/contact/index.php';
            }
        } else {
            header('Location: /contact');
            exit;
        }
    }
}