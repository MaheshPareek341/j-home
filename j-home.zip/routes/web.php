

<?php


$router->post('/contact/submit', [Controllers\ContactController::class, 'submit']);