 <!-- End #main --> <!-- ======= Footer ======= --> 
      <footer id="footer" class="footer">
         <div class="copyright"> &copy; Copyright <strong><span>J Home Furnishings</span></strong>. All Rights Reserved </div>
         <div class="credits">
         </div>
      </footer>
      <!-- End Footer --> <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> <!-- Vendor JS Files --> 
      <script src="<?= base_url() ?>assets/admin/vendor/apexcharts/apexcharts.min.js"></script> 
      <script src="<?= base_url() ?>assets/admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
      <script src="<?= base_url() ?>assets/admin/vendor/chart.js/chart.umd.js"></script>
      <script src="<?= base_url() ?>assets/admin/vendor/echarts/echarts.min.js"></script> 
      <script src="<?= base_url() ?>assets/admin/vendor/quill/quill.js"></script>
      <script src="<?= base_url() ?>assets/admin/vendor/simple-datatables/simple-datatables.js"></script> 
      <script src="<?= base_url() ?>assets/admin/vendor/tinymce/tinymce.min.js"></script> 
      <script src="<?= base_url() ?>assets/admin/vendor/php-email-form/validate.js"></script> <!-- Template Main JS File --> 
      <script src="<?= base_url() ?>assets/admin/js/main.js"></script> 
   </body>
</html>