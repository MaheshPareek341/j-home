	<div data-elementor-type="footer" data-elementor-id="23157"
		class="elementor elementor-23157 elementor-location-footer" data-elementor-post-type="elementor_library">
		<footer class="elementor-element elementor-element-72a61f8b e-flex e-con-boxed e-con e-parent"
			data-id="72a61f8b" data-element_type="container"
			data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="e-con-inner">
				<div class="elementor-element elementor-element-158dde32 e-flex e-con-boxed e-con e-child"
					data-id="158dde32" data-element_type="container">
					<div class="e-con-inner">
						<div class="hf-elementor-layout elementor-element elementor-element-27bef367 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
							data-id="27bef367" data-element_type="widget" data-widget_type="divider.default">
							<div class="elementor-widget-container">
								<style>
									/*! elementor - v3.21.0 - 26-05-2024 */
									.elementor-widget-divider {
										--divider-border-style: none;
										--divider-border-width: 1px;
										--divider-color: #0c0d0e;
										--divider-icon-size: 20px;
										--divider-element-spacing: 10px;
										--divider-pattern-height: 24px;
										--divider-pattern-size: 20px;
										--divider-pattern-url: none;
										--divider-pattern-repeat: repeat-x
									}

									.elementor-widget-divider .elementor-divider {
										display: flex
									}

									.elementor-widget-divider .elementor-divider__text {
										font-size: 15px;
										line-height: 1;
										max-width: 95%
									}

									.elementor-widget-divider .elementor-divider__element {
										margin: 0 var(--divider-element-spacing);
										flex-shrink: 0
									}

									.elementor-widget-divider .elementor-icon {
										font-size: var(--divider-icon-size)
									}

									.elementor-widget-divider .elementor-divider-separator {
										display: flex;
										margin: 0;
										direction: ltr
									}

									.elementor-widget-divider--view-line_icon .elementor-divider-separator,
									.elementor-widget-divider--view-line_text .elementor-divider-separator {
										align-items: center
									}

									.elementor-widget-divider--view-line_icon .elementor-divider-separator:after,
									.elementor-widget-divider--view-line_icon .elementor-divider-separator:before,
									.elementor-widget-divider--view-line_text .elementor-divider-separator:after,
									.elementor-widget-divider--view-line_text .elementor-divider-separator:before {
										display: block;
										content: "";
										border-block-end: 0;
										flex-grow: 1;
										border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
									}

									.elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
										flex-grow: 0;
										flex-shrink: 100
									}

									.elementor-widget-divider--element-align-left .elementor-divider-separator:before {
										content: none
									}

									.elementor-widget-divider--element-align-left .elementor-divider__element {
										margin-left: 0
									}

									.elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
										flex-grow: 0;
										flex-shrink: 100
									}

									.elementor-widget-divider--element-align-right .elementor-divider-separator:after {
										content: none
									}

									.elementor-widget-divider--element-align-right .elementor-divider__element {
										margin-right: 0
									}

									.elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
										flex-grow: 0;
										flex-shrink: 100
									}

									.elementor-widget-divider--element-align-start .elementor-divider-separator:before {
										content: none
									}

									.elementor-widget-divider--element-align-start .elementor-divider__element {
										margin-inline-start: 0
									}

									.elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
										flex-grow: 0;
										flex-shrink: 100
									}

									.elementor-widget-divider--element-align-end .elementor-divider-separator:after {
										content: none
									}

									.elementor-widget-divider--element-align-end .elementor-divider__element {
										margin-inline-end: 0
									}

									.elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator {
										border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
									}

									.elementor-widget-divider--separator-type-pattern {
										--divider-border-style: none
									}

									.elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,
									.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,
									.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,
									.elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator {
										width: 100%;
										min-height: var(--divider-pattern-height);
										-webkit-mask-size: var(--divider-pattern-size) 100%;
										mask-size: var(--divider-pattern-size) 100%;
										-webkit-mask-repeat: var(--divider-pattern-repeat);
										mask-repeat: var(--divider-pattern-repeat);
										background-color: var(--divider-color);
										-webkit-mask-image: var(--divider-pattern-url);
										mask-image: var(--divider-pattern-url)
									}

									.elementor-widget-divider--no-spacing {
										--divider-pattern-size: auto
									}

									.elementor-widget-divider--bg-round {
										--divider-pattern-repeat: round
									}

									.rtl .elementor-widget-divider .elementor-divider__text {
										direction: rtl
									}

									.e-con-inner>.elementor-widget-divider,
									.e-con>.elementor-widget-divider {
										width: var(--container-widget-width, 100%);
										--flex-grow: var(--container-widget-flex-grow)
									}
								</style>
								<div class="elementor-divider">
									<span class="elementor-divider-separator">
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-168cb961 e-flex e-con-boxed e-con e-child"
					data-id="168cb961" data-element_type="container">
					<div class="e-con-inner">
						<div class="elementor-element elementor-element-727063a6 e-con-full e-flex e-con e-child"
							data-id="727063a6" data-element_type="container">
							<div class="hf-elementor-layout elementor-element elementor-element-4cb72741 elementor-widget elementor-widget-heading"
								data-id="4cb72741" data-element_type="widget" data-widget_type="heading.default">
								<div class="elementor-widget-container">
									<h4 class="elementor-heading-title elementor-size-default">Useful Links</h4>
								</div>
							</div>
							<div class="hf-elementor-layout elementor-element elementor-element-17f2122b elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
								data-id="17f2122b" data-element_type="widget" data-widget_type="icon-list.default">
								<div class="elementor-widget-container">
									<link rel="stylesheet"
										href="<?=base_url()?>assets/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css">
									<ul class="elementor-icon-list-items">
										<li class="elementor-icon-list-item">
											<a href="movies">
												<span class="elementor-icon-list-text">Movies & Documentaries</span>
											</a>
										</li>
										<li class="elementor-icon-list-item">
											<a href="register">
												<span class="elementor-icon-list-text">Register for AirDrop</span>
											</a>
										</li>
										<li class="elementor-icon-list-item">
											<a href="become-an-ambassador">
												<span class="elementor-icon-list-text">Become an Ambassador</span>
											</a>
										</li>
										<li class="elementor-icon-list-item">
											<a href="#">
												<span class="elementor-icon-list-text">White Paper</span>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="elementor-element elementor-element-628eba89 e-con-full e-flex e-con e-child"
							data-id="628eba89" data-element_type="container">
							<div class="hf-elementor-layout elementor-element elementor-element-1bc0c7b1 elementor-widget elementor-widget-heading"
								data-id="1bc0c7b1" data-element_type="widget" data-widget_type="heading.default">
								<div class="elementor-widget-container">
									<h4 class="elementor-heading-title elementor-size-default">Contact Us</h4>
								</div>
							</div>
							<div class="hf-elementor-layout elementor-element elementor-element-1d1b8e4 elementor-button-align-stretch elementor-widget elementor-widget-form"
								data-id="1d1b8e4" data-element_type="widget"
								data-settings="{&quot;step_next_label&quot;:&quot;Next&quot;,&quot;step_previous_label&quot;:&quot;Previous&quot;,&quot;button_width&quot;:&quot;100&quot;,&quot;step_type&quot;:&quot;number_text&quot;,&quot;step_icon_shape&quot;:&quot;circle&quot;}"
								data-widget_type="form.default">
								<div class="elementor-widget-container">
									<style>
										/*! elementor-pro - v3.21.0 - 20-05-2024 */
										.elementor-button.elementor-hidden,
										.elementor-hidden {
											display: none
										}

										.e-form__step {
											width: 100%
										}

										.e-form__step:not(.elementor-hidden) {
											display: flex;
											flex-wrap: wrap
										}

										.e-form__buttons {
											flex-wrap: wrap
										}

										.e-form__buttons,
										.e-form__buttons__wrapper {
											display: flex
										}

										.e-form__indicators {
											display: flex;
											justify-content: space-between;
											align-items: center;
											flex-wrap: nowrap;
											font-size: 13px;
											margin-bottom: var(--e-form-steps-indicators-spacing)
										}

										.e-form__indicators__indicator {
											display: flex;
											flex-direction: column;
											align-items: center;
											justify-content: center;
											flex-basis: 0;
											padding: 0 var(--e-form-steps-divider-gap)
										}

										.e-form__indicators__indicator__progress {
											width: 100%;
											position: relative;
											background-color: var(--e-form-steps-indicator-progress-background-color);
											border-radius: var(--e-form-steps-indicator-progress-border-radius);
											overflow: hidden
										}

										.e-form__indicators__indicator__progress__meter {
											width: var(--e-form-steps-indicator-progress-meter-width, 0);
											height: var(--e-form-steps-indicator-progress-height);
											line-height: var(--e-form-steps-indicator-progress-height);
											padding-right: 15px;
											border-radius: var(--e-form-steps-indicator-progress-border-radius);
											background-color: var(--e-form-steps-indicator-progress-color);
											color: var(--e-form-steps-indicator-progress-meter-color);
											text-align: right;
											transition: width .1s linear
										}

										.e-form__indicators__indicator:first-child {
											padding-left: 0
										}

										.e-form__indicators__indicator:last-child {
											padding-right: 0
										}

										.e-form__indicators__indicator--state-inactive {
											color: var(--e-form-steps-indicator-inactive-primary-color, #c2cbd2)
										}

										.e-form__indicators__indicator--state-inactive [class*=indicator--shape-]:not(.e-form__indicators__indicator--shape-none) {
											background-color: var(--e-form-steps-indicator-inactive-secondary-color, #fff)
										}

										.e-form__indicators__indicator--state-inactive object,
										.e-form__indicators__indicator--state-inactive svg {
											fill: var(--e-form-steps-indicator-inactive-primary-color, #c2cbd2)
										}

										.e-form__indicators__indicator--state-active {
											color: var(--e-form-steps-indicator-active-primary-color, #39b54a);
											border-color: var(--e-form-steps-indicator-active-secondary-color, #fff)
										}

										.e-form__indicators__indicator--state-active [class*=indicator--shape-]:not(.e-form__indicators__indicator--shape-none) {
											background-color: var(--e-form-steps-indicator-active-secondary-color, #fff)
										}

										.e-form__indicators__indicator--state-active object,
										.e-form__indicators__indicator--state-active svg {
											fill: var(--e-form-steps-indicator-active-primary-color, #39b54a)
										}

										.e-form__indicators__indicator--state-completed {
											color: var(--e-form-steps-indicator-completed-secondary-color, #fff)
										}

										.e-form__indicators__indicator--state-completed [class*=indicator--shape-]:not(.e-form__indicators__indicator--shape-none) {
											background-color: var(--e-form-steps-indicator-completed-primary-color, #39b54a)
										}

										.e-form__indicators__indicator--state-completed .e-form__indicators__indicator__label {
											color: var(--e-form-steps-indicator-completed-primary-color, #39b54a)
										}

										.e-form__indicators__indicator--state-completed .e-form__indicators__indicator--shape-none {
											color: var(--e-form-steps-indicator-completed-primary-color, #39b54a);
											background-color: initial
										}

										.e-form__indicators__indicator--state-completed object,
										.e-form__indicators__indicator--state-completed svg {
											fill: var(--e-form-steps-indicator-completed-secondary-color, #fff)
										}

										.e-form__indicators__indicator__icon {
											width: var(--e-form-steps-indicator-padding, 30px);
											height: var(--e-form-steps-indicator-padding, 30px);
											font-size: var(--e-form-steps-indicator-icon-size);
											border-width: 1px;
											border-style: solid;
											display: flex;
											justify-content: center;
											align-items: center;
											overflow: hidden;
											margin-bottom: 10px
										}

										.e-form__indicators__indicator__icon img,
										.e-form__indicators__indicator__icon object,
										.e-form__indicators__indicator__icon svg {
											width: var(--e-form-steps-indicator-icon-size);
											height: auto
										}

										.e-form__indicators__indicator__icon .e-font-icon-svg {
											height: 1em
										}

										.e-form__indicators__indicator__number {
											width: var(--e-form-steps-indicator-padding, 30px);
											height: var(--e-form-steps-indicator-padding, 30px);
											border-width: 1px;
											border-style: solid;
											display: flex;
											justify-content: center;
											align-items: center;
											margin-bottom: 10px
										}

										.e-form__indicators__indicator--shape-circle {
											border-radius: 50%
										}

										.e-form__indicators__indicator--shape-square {
											border-radius: 0
										}

										.e-form__indicators__indicator--shape-rounded {
											border-radius: 5px
										}

										.e-form__indicators__indicator--shape-none {
											border: 0
										}

										.e-form__indicators__indicator__label {
											text-align: center
										}

										.e-form__indicators__indicator__separator {
											width: 100%;
											height: var(--e-form-steps-divider-width);
											background-color: #babfc5
										}

										.e-form__indicators--type-icon,
										.e-form__indicators--type-icon_text,
										.e-form__indicators--type-number,
										.e-form__indicators--type-number_text {
											align-items: flex-start
										}

										.e-form__indicators--type-icon .e-form__indicators__indicator__separator,
										.e-form__indicators--type-icon_text .e-form__indicators__indicator__separator,
										.e-form__indicators--type-number .e-form__indicators__indicator__separator,
										.e-form__indicators--type-number_text .e-form__indicators__indicator__separator {
											margin-top: calc(var(--e-form-steps-indicator-padding, 30px) / 2 - var(--e-form-steps-divider-width, 1px) / 2)
										}

										.elementor-field-type-hidden {
											display: none
										}

										.elementor-field-type-html {
											display: inline-block
										}

										.elementor-field-type-tel input {
											direction: inherit
										}

										.elementor-login .elementor-lost-password,
										.elementor-login .elementor-remember-me {
											font-size: .85em
										}

										.elementor-field-type-recaptcha_v3 .elementor-field-label {
											display: none
										}

										.elementor-field-type-recaptcha_v3 .grecaptcha-badge {
											z-index: 1
										}

										.elementor-button .elementor-form-spinner {
											order: 3
										}

										.elementor-form .elementor-button>span {
											display: flex;
											justify-content: center;
											align-items: center
										}

										.elementor-form .elementor-button .elementor-button-text {
											white-space: normal;
											flex-grow: 0
										}

										.elementor-form .elementor-button svg {
											height: auto
										}

										.elementor-form .elementor-button .e-font-icon-svg {
											height: 1em
										}

										.elementor-select-wrapper .select-caret-down-wrapper {
											position: absolute;
											top: 50%;
											transform: translateY(-50%);
											inset-inline-end: 10px;
											pointer-events: none;
											font-size: 11px
										}

										.elementor-select-wrapper .select-caret-down-wrapper svg {
											display: unset;
											width: 1em;
											aspect-ratio: unset;
											fill: currentColor
										}

										.elementor-select-wrapper .select-caret-down-wrapper i {
											font-size: 19px;
											line-height: 2
										}

										.elementor-select-wrapper.remove-before:before {
											content: "" !important
										}
									</style>
								
								</div>
							</div>
							<div class="hf-elementor-layout elementor-element elementor-element-b77eeb7 elementor-widget elementor-widget-heading"
								data-id="b77eeb7" data-element_type="widget" data-widget_type="heading.default">
								<div class="elementor-widget-container">
									<p class="elementor-heading-title elementor-size-default">
									    <a href="mailto:info@networkstate.com" style="font-size:16px; color:white">info@networkstate.com</a><br>
									   
								</div>
							</div>
						</div>
						<div class="elementor-element elementor-element-25414753 e-con-full e-flex e-con e-child"
							data-id="25414753" data-element_type="container">
							<div class="hf-elementor-layout elementor-element elementor-element-6deb4ef4 elementor-widget elementor-widget-heading"
								data-id="6deb4ef4" data-element_type="widget" data-widget_type="heading.default">
								<div class="elementor-widget-container">
									<h4 class="elementor-heading-title elementor-size-default">Socials</h4>
								</div>
							</div>
							<div class="hf-elementor-layout elementor-element elementor-element-b82e219 elementor-widget elementor-widget-button"
								data-id="b82e219" data-element_type="widget" data-widget_type="button.default">
								<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
										<a class="elementor-button elementor-button-link elementor-size-sm"
											href="#">
											<span class="elementor-button-content-wrapper">
												<span class="elementor-button-text">Telegram</span>
											</span>
										</a>
									</div>
								</div>
							</div>
							<div class="hf-elementor-layout elementor-element elementor-element-54853a6 elementor-widget elementor-widget-button"
								data-id="54853a6" data-element_type="widget" data-widget_type="button.default">
								<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
										<a class="elementor-button elementor-button-link elementor-size-sm"
											href="#">
											<span class="elementor-button-content-wrapper">
												<span class="elementor-button-text">Twitter</span>
											</span>
										</a>
									</div>
								</div>
							</div>
							<div class="hf-elementor-layout elementor-element elementor-element-1991c9ff elementor-widget elementor-widget-button"
								data-id="1991c9ff" data-element_type="widget" data-widget_type="button.default">
								<div class="elementor-widget-container">
									<div class="elementor-button-wrapper">
										<a class="elementor-button elementor-button-link elementor-size-sm"
											href="#">
											<span class="elementor-button-content-wrapper">
												<span class="elementor-button-text">Linkedin</span>
											</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-6f639b02 e-flex e-con-boxed e-con e-child"
					data-id="6f639b02" data-element_type="container" style="margin-bottom:50px">
					<div class="e-con-inner">
						<div class="hf-elementor-layout elementor-element elementor-element-216f2ad5 elementor-widget elementor-widget-heading"
							data-id="216f2ad5" data-element_type="widget" data-widget_type="heading.default">
							<div class="elementor-widget-container">
							    <img src="<?=base_url()?>assets/wp-content/solana.jpg" style="width:200px;">
									<p class="elementor-heading-title elementor-size-default" style="margin:0px 0 10px 0 !important">Backed by solana foundation</p>
										<p class="elementor-heading-title elementor-size-default">Copyright © 2024 Network State. All
								Rights Reserved.</p>
									
							</div>
						</div>
						<!--<div class="hf-elementor-layout elementor-element elementor-element-334802fd elementor-invisible elementor-widget elementor-widget-heading"-->
						<!--	data-id="334802fd" data-element_type="widget"-->
						<!--	data-settings="{&quot;_animation&quot;:&quot;slideInUp&quot;,&quot;_animation_delay&quot;:100}"-->
						<!--	data-widget_type="heading.default">-->
						<!--	<div class="elementor-widget-container" style="margin: -2.5rem 0rem -6rem 0rem;">-->
						<!--		<span class="elementor-heading-title elementor-size-default" style="font-size: 1.5rem !important; letter-spacing: 0px !important;">Backed by Solana Foundation</span>-->
						<!--	</div>-->
						<!--</div>-->
					</div>
				</div>
			</div>
		</footer>
	</div>

	<script type="text/template" id="tmpl-elementor-templates-modal__header">
	<div class="elementor-templates-modal__header__logo-area"></div>
	<div class="elementor-templates-modal__header__menu-area"></div>
	<div class="elementor-templates-modal__header__items-area">
		<# if ( closeType ) { #>
			<div class="elementor-templates-modal__header__close elementor-templates-modal__header__close--{{{ closeType }}} elementor-templates-modal__header__item">
				<# if ( 'skip' === closeType ) { #>
				<span>Skip</span>
				<# } #>
				<i class="eicon-close" aria-hidden="true"></i>
				<span class="elementor-screen-only">Close</span>
			</div>
		<# } #>
		<div id="elementor-template-library-header-tools"></div>
	</div>
</script>

	<script type="text/template" id="tmpl-elementor-templates-modal__header__logo">
	<span class="elementor-templates-modal__header__logo__icon-wrapper e-logo-wrapper">
		<i class="eicon-elementor"></i>
	</span>
	<span class="elementor-templates-modal__header__logo__title">{{{ title }}}</span>
</script>
	<script type='text/javascript'>
		const lazyloadRunObserver = () => {
			const lazyloadBackgrounds = document.querySelectorAll(`.e-con.e-parent:not(.e-lazyloaded)`);
			const lazyloadBackgroundObserver = new IntersectionObserver((entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						let lazyloadBackground = entry.target;
						if (lazyloadBackground) {
							lazyloadBackground.classList.add('e-lazyloaded');
						}
						lazyloadBackgroundObserver.unobserve(entry.target);
					}
				});
			}, { rootMargin: '200px 0px 200px 0px' });
			lazyloadBackgrounds.forEach((lazyloadBackground) => {
				lazyloadBackgroundObserver.observe(lazyloadBackground);
			});
		};
		const events = [
			'DOMContentLoaded',
			'elementor/lazyload/observe',
		];
		events.forEach((event) => {
			document.addEventListener(event, lazyloadRunObserver);
		});
	</script>
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/masvideos-no-js/, 'masvideos-js');
		document.body.className = c;
	</script>
	<link rel='stylesheet' id='pms-dc-style-front-end-css'
		href='<?=base_url()?>assets/wp-content/plugins/paid-member-subscriptions/includes/features/discount-codes/assets/css/style-front-endadc6.css?ver=6.5.5'
		type='text/css' media='all' />
	<link rel='stylesheet' id='pms-style-front-end-css'
		href='<?=base_url()?>assets/wp-content/plugins/paid-member-subscriptions/assets/css/style-front-end946b.css?ver=2.12.3'
		type='text/css' media='all' />
	<link rel='stylesheet' id='e-animations-css'
		href='<?=base_url()?>assets/wp-content/plugins/elementor/assets/lib/animations/animations.min3cad.css?ver=3.21.8' type='text/css'
		media='all' />
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/contact-form-7/includes/swv/js/indexa950.js?ver=5.9.6"
		id="swv-js"></script>
	<script type="text/javascript" id="contact-form-7-js-extra">
		/* <![CDATA[ */
		var wpcf7 = { "api": { "root": "https:\/\/earntv.io\/wp-json\/", "namespace": "contact-form-7\/v1" } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/contact-form-7/includes/js/indexa950.js?ver=5.9.6"
		id="contact-form-7-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/iqonic-layouts/includes/Elementor/assets/js/generalf269.js?ver=1.0.1"
		id="layout-general-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/popper.min1efe.js?ver=1.2.8"
		id="popper-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/bootstrap-util.min1efe.js?ver=1.2.8"
		id="bootstrap-util-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/bootstrap-tab.min1efe.js?ver=1.2.8"
		id="bootstrap-tab-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/bootstrap-dropdown.min1efe.js?ver=1.2.8"
		id="bootstrap-dropdown-js"></script>
	<script type="text/javascript" id="masvideos-playlist-tv-show-js-extra">
		/* <![CDATA[ */
		var masvideos_playlist_tv_show_params = { "ajax_url": "\/wp-admin\/admin-ajax.php", "masvideos_ajax_url": "\/?masvideos-ajax=%%endpoint%%" };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/playlist-tv-show.min1efe.js?ver=1.2.8"
		id="masvideos-playlist-tv-show-js"></script>
	<script type="text/javascript" id="masvideos-playlist-video-js-extra">
		/* <![CDATA[ */
		var masvideos_playlist_video_params = { "ajax_url": "\/wp-admin\/admin-ajax.php", "masvideos_ajax_url": "\/?masvideos-ajax=%%endpoint%%" };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/playlist-video.min1efe.js?ver=1.2.8"
		id="masvideos-playlist-video-js"></script>
	<script type="text/javascript" id="masvideos-playlist-movie-js-extra">
		/* <![CDATA[ */
		var masvideos_playlist_movie_params = { "ajax_url": "\/wp-admin\/admin-ajax.php", "masvideos_ajax_url": "\/?masvideos-ajax=%%endpoint%%" };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/playlist-movie.min1efe.js?ver=1.2.8"
		id="masvideos-playlist-movie-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/frontend/gallery-flip.min1efe.js?ver=1.2.8"
		id="masvideos-gallery-flip-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/streamit-extensions/includes/Elementor/assets/js/LoadMore_Customa1ec.js?ver=2.3.0"
		id="LoadMore_Custom-js"></script>
	<script type="text/javascript" id="wp_ulike-js-extra">
		/* <![CDATA[ */
		var wp_ulike_params = { "ajax_url": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php", "notifications": "0" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/wp-ulike/assets/js/wp-ulike.min1849.js?ver=4.7.0"
		id="wp_ulike-js"></script>
	<script type="text/javascript" id="mr-frontend-script-js-extra">
		/* <![CDATA[ */
		var mr_frontend_data = { "ajax_url": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php", "ajax_nonce": "f61d7e030f", "icon_classes": "{\"star_full\":\"fas fa-star mr-star-full\",\"star_hover\":\"fas fa-star mr-star-hover\",\"star_half\":\"fas fa-star-half-alt mr-star-half\",\"star_empty\":\"far fa-star mr-star-empty\",\"minus\":\"fas fa-minus mr-minus\",\"spinner\":\"fas fa-spinner fa-spin mr-spinner\"}", "use_custom_star_images": "false" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/multi-rating/assets/js/frontendfd20.js?ver=5.0.6a"
		id="mr-frontend-script-js"></script>
	<script type="text/javascript" src="wp-includes/js/underscore.mind584.js?ver=1.13.4" id="underscore-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/vendor/slick/slick.mina1ec.js?ver=2.3.0"
		id="slick-min-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/vendor/slick/slick-animation.mina1ec.js?ver=2.3.0"
		id="slick-animation-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/masvideos/assets/js/select2/select2.full.minfa0c.js?ver=4.0.3" id="select2-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/vendor/jquery.magnific-popup.mina1ec.js?ver=2.3.0"
		id="magnific-popup-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/vendor/bootstrap.mina1ec.js?ver=2.3.0"
		id="bootstrap-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/vendor/wow.mina1ec.js?ver=2.3.0"
		id="wow-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/custom.mina1ec.js?ver=2.3.0"
		id="streamit-custom-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit/assets/js/vendor/select2.mina1ec.js?ver=2.3.0"
		id="select2-streamit-js"></script>
	<script type="text/javascript" src="wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2"
		id="jquery-ui-core-js"></script>
	<script type="text/javascript" src="wp-includes/js/jquery/ui/mouse.min3f14.js?ver=1.13.2"
		id="jquery-ui-mouse-js"></script>
	<script type="text/javascript" src="wp-includes/js/jquery/ui/draggable.min3f14.js?ver=1.13.2"
		id="jquery-ui-draggable-js"></script>
	<script type="text/javascript" src="wp-includes/js/backbone.min91ce.js?ver=1.5.0" id="backbone-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/lib/backbone/backbone.marionette.min4ae5.js?ver=2.4.5.e1"
		id="backbone-marionette-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/lib/backbone/backbone.radio.min4b68.js?ver=1.0.4"
		id="backbone-radio-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/common-modules.min3cad.js?ver=3.21.8"
		id="elementor-common-modules-js"></script>
	<script type="text/javascript" id="elementor-web-cli-js-before">
		/* <![CDATA[ */
		var elementorWebCliConfig = { "isDebug": false, "urls": { "rest": "https:\/\/earntv.io\/wp-json\/", "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/" }, "nonce": "2eb8f4b0b6", "version": "3.21.8" };
		var elementorWebCliConfig = { "isDebug": false, "urls": { "rest": "https:\/\/earntv.io\/wp-json\/", "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/" }, "nonce": "2eb8f4b0b6", "version": "3.21.8" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/web-cli.min3cad.js?ver=3.21.8"
		id="elementor-web-cli-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/lib/dialog/dialog.mind227.js?ver=4.9.0"
		id="elementor-dialog-js"></script>
	<script type="text/javascript" id="wp-api-request-js-extra">
		/* <![CDATA[ */
		var wpApiSettings = { "root": "https:\/\/earntv.io\/wp-json\/", "nonce": "2eb8f4b0b6", "versionString": "wp\/v2\/" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="wp-includes/js/api-request.minadc6.js?ver=6.5.5"
		id="wp-api-request-js"></script>
	<script type="text/javascript" id="elementor-dev-tools-js-before">
		/* <![CDATA[ */
		var elementorDevToolsConfig = { "isDebug": false, "urls": { "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/" }, "deprecation": { "soft_notices": [], "soft_version_count": 4, "hard_version_count": 8, "current_version": "3.21.8" } };
		var elementorDevToolsConfig = { "isDebug": false, "urls": { "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/" }, "deprecation": { "soft_notices": [], "soft_version_count": 4, "hard_version_count": 8, "current_version": "3.21.8" } };
		var elementorDevToolsConfig = { "isDebug": false, "urls": { "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/" }, "deprecation": { "soft_notices": [], "soft_version_count": 4, "hard_version_count": 8, "current_version": "3.21.8" } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/dev-tools.min3cad.js?ver=3.21.8"
		id="elementor-dev-tools-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2"
		id="wp-polyfill-inert-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/vendor/regenerator-runtime.min6c85.js?ver=0.14.0"
		id="regenerator-runtime-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0"
		id="wp-polyfill-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/hooks.min2757.js?ver=2810c76e705dd1a53b18"
		id="wp-hooks-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/i18n.minc33c.js?ver=5e580eb46a90c2b997e6"
		id="wp-i18n-js"></script>
	<script type="text/javascript" id="wp-i18n-js-after">
		/* <![CDATA[ */
		wp.i18n.setLocaleData({ 'text direction\u0004ltr': ['ltr'] });
		/* ]]> */
	</script>
	<script type="text/javascript" id="elementor-common-js-before">
		/* <![CDATA[ */
		var elementorCommonConfig = { "version": "3.21.8", "isRTL": false, "isDebug": false, "isElementorDebug": false, "activeModules": ["ajax", "connect", "event-tracker"], "experimentalFeatures": { "e_optimized_assets_loading": true, "e_optimized_css_loading": true, "e_font_icon_svg": true, "additional_custom_breakpoints": true, "container": true, "e_swiper_latest": true, "e_optimized_control_loading": true, "theme_builder_v2": true, "home_screen": true, "landing-pages": true, "nested-elements": true, "e_lazyload": true, "form-submissions": true }, "urls": { "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/", "rest": "https:\/\/earntv.io\/wp-json\/" }, "filesUpload": { "unfilteredFiles": false }, "library_connect": { "is_connected": false, "subscription_plans": { "free": { "label": null, "promotion_url": null, "color": null }, "essential": { "label": "Pro", "promotion_url": "https:\/\/my.elementor.com\/upgrade-subscription\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro", "color": "#92003B" }, "essential-oct2023": { "label": "Advanced", "promotion_url": "https:\/\/my.elementor.com\/upgrade-subscription\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro", "color": "#92003B" }, "advanced": { "label": "Advanced", "promotion_url": "https:\/\/my.elementor.com\/upgrade-subscription\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro", "color": "#92003B" }, "expert": { "label": "Expert", "promotion_url": "https:\/\/my.elementor.com\/upgrade-subscription\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro", "color": "#92003B" }, "agency": { "label": "Agency", "promotion_url": "https:\/\/my.elementor.com\/upgrade-subscription\/?utm_source=template-library&utm_medium=wp-dash&utm_campaign=gopro", "color": "#92003B" } }, "base_access_level": 0, "base_access_tier": "free", "current_access_level": 1, "current_access_tier": "essential-oct2023" }, "ajax": { "url": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php", "nonce": "9a9efcd3d1" }, "connect": [], "event-tracker": { "isUserDataShared": false } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/common.min3cad.js?ver=3.21.8"
		id="elementor-common-js"></script>
	<script type="text/javascript" id="elementor-app-loader-js-before">
		/* <![CDATA[ */
		var elementorAppConfig = { "menu_url": "https:\/\/earntv.io\/wp-admin\/admin.php?page=elementor-app&ver=3.21.8#\/site-editor", "assets_url": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/", "pages_url": "https:\/\/earntv.io\/wp-admin\/edit.php?post_type=page", "return_url": "https:\/\/earntv.io\/wp-admin\/", "hasPro": true, "admin_url": "https:\/\/earntv.io\/wp-admin\/", "login_url": "https:\/\/earntv.io\/wp-login.php", "base_url": "https:\/\/earntv.io\/wp-admin\/admin.php?page=elementor-app&ver=3.21.8", "promotion": { "upgrade_url": "https:\/\/go.elementor.com\/go-pro-theme-builder\/" }, "site-editor": [], "onboarding": [] };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/app-loader.min3cad.js?ver=3.21.8"
		id="elementor-app-loader-js"></script>
	<script type="text/javascript" id="uprime-backstage-js-js-extra">
		/* <![CDATA[ */
		var ajax_object = { "ajax_url": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php", "site_url": "https:\/\/earntv.io\/", "rest": { "endpoints": { "my_endpoint": "https:\/\/earntv.io\/wp-json\/uprime\/v1\/update-credits" }, "timeout": 60, "nonce": "2eb8f4b0b6", "action_nonce": "7ace4780d0" }, "plan_details": "3" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/uprime-backstage/js/uprime-backstage5247.js?ver=0.76"
		id="uprime-backstage-js-js"></script>
	<script type="text/javascript"
		src="../www.google.com/recaptcha/api3f8a.js?render=6Lf5gn0pAAAAAGJrdYbrtOw2cD1nFN0Jcbi2WSYZ&amp;ver=3.0"
		id="google-recaptcha-js"></script>
	<script type="text/javascript" id="wpcf7-recaptcha-js-extra">
		/* <![CDATA[ */
		var wpcf7_recaptcha = { "sitekey": "6Lf5gn0pAAAAAGJrdYbrtOw2cD1nFN0Jcbi2WSYZ", "actions": { "homepage": "homepage", "contactform": "contactform" } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/contact-form-7/modules/recaptcha/indexa950.js?ver=5.9.6"
		id="wpcf7-recaptcha-js"></script>
	<script type="text/javascript" id="streamit-custom-js-js-after">
		/* <![CDATA[ */
		jQuery(document).ready(function ($) {

		});
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit-child/assets/js/Generaladc6.js?ver=6.5.5"
		id="General-js"></script>
	<script type="text/javascript" id="streamit-loadmore-chid-js-extra">
		/* <![CDATA[ */
		var streamit_loadmore_params = { "ajaxurl": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php", "term_id": "17024", "posts": "{\"error\":\"\",\"m\":\"\",\"p\":\"17024\",\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment\":\"\",\"attachment_id\":0,\"name\":\"\",\"pagename\":\"\",\"page_id\":\"17024\",\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"search_columns\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"update_menu_item_cache\":false,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":10,\"nopaging\":false,\"comments_per_page\":\"50\",\"no_found_rows\":false,\"order\":\"DESC\"}", "current_page": "1", "max_page": "0", "template_dir": "https:\/\/earntv.io\/wp-content\/themes\/streamit" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit-child/assets/js/loadmore.min8a54.js?ver=1.0.0"
		id="streamit-loadmore-chid-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/themes/streamit-child/assets/js/uprime-customadc6.js?ver=6.5.5"
		id="uprime-custom-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min1576.js?ver=1.2.1"
		id="smartmenus-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.min3958.js?ver=0.2.1"
		id="jquery-numerator-js"></script>
	<script type="text/javascript" id="pms-frontend-discount-code-js-js-extra">
		/* <![CDATA[ */
		var pms_discount_object = { "ajax_url": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php" };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/paid-member-subscriptions/includes/features/discount-codes/assets/js/frontend-discount-code946b.js?ver=2.12.3"
		id="pms-frontend-discount-code-js-js"></script>
	<script type="text/javascript" id="pms-front-end-js-extra">
		/* <![CDATA[ */
		var pmsGdpr = { "delete_url": "https:\/\/earntv.io?pms_user=0&pms_action=pms_delete_user&pms_nonce=f5a82df317", "delete_text": "Type DELETE to confirm deleting your account and all data associated with it:", "delete_error_text": "You did not type DELETE. Try again!" };
		var PMS_States = { "ZA": { "EC": "Eastern Cape", "FS": "Free State", "GP": "Gauteng", "KZN": "KwaZulu-Natal", "LP": "Limpopo", "MP": "Mpumalanga", "NC": "Northern Cape", "NW": "North West", "WC": "Western Cape" }, "HU": { "BK": "B\u00e1cs-Kiskun", "BE": "B\u00e9k\u00e9s", "BA": "Baranya", "BZ": "Borsod-Aba\u00faj-Zempl\u00e9n", "BU": "Budapest", "CS": "Csongr\u00e1d", "FE": "Fej\u00e9r", "GS": "Gy\u0151r-Moson-Sopron", "HB": "Hajd\u00fa-Bihar", "HE": "Heves", "JN": "J\u00e1sz-Nagykun-Szolnok", "KE": "Kom\u00e1rom-Esztergom", "NO": "N\u00f3gr\u00e1d", "PE": "Pest", "SO": "Somogy", "SZ": "Szabolcs-Szatm\u00e1r-Bereg", "TO": "Tolna", "VA": "Vas", "VE": "Veszpr\u00e9m", "ZA": "Zala" }, "BG": { "BG-01": "Blagoevgrad", "BG-02": "Burgas", "BG-08": "Dobrich", "BG-07": "Gabrovo", "BG-26": "Haskovo", "BG-09": "Kardzhali", "BG-10": "Kyustendil", "BG-11": "Lovech", "BG-12": "Montana", "BG-13": "Pazardzhik", "BG-14": "Pernik", "BG-15": "Pleven", "BG-16": "Plovdiv", "BG-17": "Razgrad", "BG-18": "Ruse", "BG-27": "Shumen", "BG-19": "Silistra", "BG-20": "Sliven", "BG-21": "Smolyan", "BG-23": "Sofia", "BG-22": "Sofia-Grad", "BG-24": "Stara Zagora", "BG-25": "Targovishte", "BG-03": "Varna", "BG-04": "Veliko Tarnovo", "BG-05": "Vidin", "BG-06": "Vratsa", "BG-28": "Yambol" }, "TH": { "TH-37": "Amnat Charoen (&#3629;&#3635;&#3609;&#3634;&#3592;&#3648;&#3592;&#3619;&#3636;&#3597;)", "TH-15": "Ang Thong (&#3629;&#3656;&#3634;&#3591;&#3607;&#3629;&#3591;)", "TH-14": "Ayutthaya (&#3614;&#3619;&#3632;&#3609;&#3588;&#3619;&#3624;&#3619;&#3637;&#3629;&#3618;&#3640;&#3608;&#3618;&#3634;)", "TH-10": "Bangkok (&#3585;&#3619;&#3640;&#3591;&#3648;&#3607;&#3614;&#3617;&#3627;&#3634;&#3609;&#3588;&#3619;)", "TH-38": "Bueng Kan (&#3610;&#3638;&#3591;&#3585;&#3634;&#3628;)", "TH-31": "Buri Ram (&#3610;&#3640;&#3619;&#3637;&#3619;&#3633;&#3617;&#3618;&#3660;)", "TH-24": "Chachoengsao (&#3593;&#3632;&#3648;&#3594;&#3636;&#3591;&#3648;&#3607;&#3619;&#3634;)", "TH-18": "Chai Nat (&#3594;&#3633;&#3618;&#3609;&#3634;&#3607;)", "TH-36": "Chaiyaphum (&#3594;&#3633;&#3618;&#3616;&#3641;&#3617;&#3636;)", "TH-22": "Chanthaburi (&#3592;&#3633;&#3609;&#3607;&#3610;&#3640;&#3619;&#3637;)", "TH-50": "Chiang Mai (&#3648;&#3594;&#3637;&#3618;&#3591;&#3651;&#3627;&#3617;&#3656;)", "TH-57": "Chiang Rai (&#3648;&#3594;&#3637;&#3618;&#3591;&#3619;&#3634;&#3618;)", "TH-20": "Chonburi (&#3594;&#3621;&#3610;&#3640;&#3619;&#3637;)", "TH-86": "Chumphon (&#3594;&#3640;&#3617;&#3614;&#3619;)", "TH-46": "Kalasin (&#3585;&#3634;&#3628;&#3626;&#3636;&#3609;&#3608;&#3640;&#3660;)", "TH-62": "Kamphaeng Phet (&#3585;&#3635;&#3649;&#3614;&#3591;&#3648;&#3614;&#3594;&#3619;)", "TH-71": "Kanchanaburi (&#3585;&#3634;&#3597;&#3592;&#3609;&#3610;&#3640;&#3619;&#3637;)", "TH-40": "Khon Kaen (&#3586;&#3629;&#3609;&#3649;&#3585;&#3656;&#3609;)", "TH-81": "Krabi (&#3585;&#3619;&#3632;&#3610;&#3637;&#3656;)", "TH-52": "Lampang (&#3621;&#3635;&#3611;&#3634;&#3591;)", "TH-51": "Lamphun (&#3621;&#3635;&#3614;&#3641;&#3609;)", "TH-42": "Loei (&#3648;&#3621;&#3618;)", "TH-16": "Lopburi (&#3621;&#3614;&#3610;&#3640;&#3619;&#3637;)", "TH-58": "Mae Hong Son (&#3649;&#3617;&#3656;&#3630;&#3656;&#3629;&#3591;&#3626;&#3629;&#3609;)", "TH-44": "Maha Sarakham (&#3617;&#3627;&#3634;&#3626;&#3634;&#3619;&#3588;&#3634;&#3617;)", "TH-49": "Mukdahan (&#3617;&#3640;&#3585;&#3604;&#3634;&#3627;&#3634;&#3619;)", "TH-26": "Nakhon Nayok (&#3609;&#3588;&#3619;&#3609;&#3634;&#3618;&#3585;)", "TH-73": "Nakhon Pathom (&#3609;&#3588;&#3619;&#3611;&#3600;&#3617;)", "TH-48": "Nakhon Phanom (&#3609;&#3588;&#3619;&#3614;&#3609;&#3617;)", "TH-30": "Nakhon Ratchasima (&#3609;&#3588;&#3619;&#3619;&#3634;&#3594;&#3626;&#3637;&#3617;&#3634;)", "TH-60": "Nakhon Sawan (&#3609;&#3588;&#3619;&#3626;&#3623;&#3619;&#3619;&#3588;&#3660;)", "TH-80": "Nakhon Si Thammarat (&#3609;&#3588;&#3619;&#3624;&#3619;&#3637;&#3608;&#3619;&#3619;&#3617;&#3619;&#3634;&#3594;)", "TH-55": "Nan (&#3609;&#3656;&#3634;&#3609;)", "TH-96": "Narathiwat (&#3609;&#3619;&#3634;&#3608;&#3636;&#3623;&#3634;&#3626;)", "TH-39": "Nong Bua Lam Phu (&#3627;&#3609;&#3629;&#3591;&#3610;&#3633;&#3623;&#3621;&#3635;&#3616;&#3641;)", "TH-43": "Nong Khai (&#3627;&#3609;&#3629;&#3591;&#3588;&#3634;&#3618;)", "TH-12": "Nonthaburi (&#3609;&#3609;&#3607;&#3610;&#3640;&#3619;&#3637;)", "TH-13": "Pathum Thani (&#3611;&#3607;&#3640;&#3617;&#3608;&#3634;&#3609;&#3637;)", "TH-94": "Pattani (&#3611;&#3633;&#3605;&#3605;&#3634;&#3609;&#3637;)", "TH-82": "Phang Nga (&#3614;&#3633;&#3591;&#3591;&#3634;)", "TH-93": "Phatthalung (&#3614;&#3633;&#3607;&#3621;&#3640;&#3591;)", "TH-56": "Phayao (&#3614;&#3632;&#3648;&#3618;&#3634;)", "TH-67": "Phetchabun (&#3648;&#3614;&#3594;&#3619;&#3610;&#3641;&#3619;&#3603;&#3660;)", "TH-76": "Phetchaburi (&#3648;&#3614;&#3594;&#3619;&#3610;&#3640;&#3619;&#3637;)", "TH-66": "Phichit (&#3614;&#3636;&#3592;&#3636;&#3605;&#3619;)", "TH-65": "Phitsanulok (&#3614;&#3636;&#3625;&#3603;&#3640;&#3650;&#3621;&#3585;)", "TH-54": "Phrae (&#3649;&#3614;&#3619;&#3656;)", "TH-83": "Phuket (&#3616;&#3641;&#3648;&#3585;&#3655;&#3605;)", "TH-25": "Prachin Buri (&#3611;&#3619;&#3634;&#3592;&#3637;&#3609;&#3610;&#3640;&#3619;&#3637;)", "TH-77": "Prachuap Khiri Khan (&#3611;&#3619;&#3632;&#3592;&#3623;&#3610;&#3588;&#3637;&#3619;&#3637;&#3586;&#3633;&#3609;&#3608;&#3660;)", "TH-85": "Ranong (&#3619;&#3632;&#3609;&#3629;&#3591;)", "TH-70": "Ratchaburi (&#3619;&#3634;&#3594;&#3610;&#3640;&#3619;&#3637;)", "TH-21": "Rayong (&#3619;&#3632;&#3618;&#3629;&#3591;)", "TH-45": "Roi Et (&#3619;&#3657;&#3629;&#3618;&#3648;&#3629;&#3655;&#3604;)", "TH-27": "Sa Kaeo (&#3626;&#3619;&#3632;&#3649;&#3585;&#3657;&#3623;)", "TH-47": "Sakon Nakhon (&#3626;&#3585;&#3621;&#3609;&#3588;&#3619;)", "TH-11": "Samut Prakan (&#3626;&#3617;&#3640;&#3607;&#3619;&#3611;&#3619;&#3634;&#3585;&#3634;&#3619;)", "TH-74": "Samut Sakhon (&#3626;&#3617;&#3640;&#3607;&#3619;&#3626;&#3634;&#3588;&#3619;)", "TH-75": "Samut Songkhram (&#3626;&#3617;&#3640;&#3607;&#3619;&#3626;&#3591;&#3588;&#3619;&#3634;&#3617;)", "TH-19": "Saraburi (&#3626;&#3619;&#3632;&#3610;&#3640;&#3619;&#3637;)", "TH-91": "Satun (&#3626;&#3605;&#3641;&#3621;)", "TH-17": "Sing Buri (&#3626;&#3636;&#3591;&#3627;&#3660;&#3610;&#3640;&#3619;&#3637;)", "TH-33": "Sisaket (&#3624;&#3619;&#3637;&#3626;&#3632;&#3648;&#3585;&#3625;)", "TH-90": "Songkhla (&#3626;&#3591;&#3586;&#3621;&#3634;)", "TH-64": "Sukhothai (&#3626;&#3640;&#3650;&#3586;&#3607;&#3633;&#3618;)", "TH-72": "Suphan Buri (&#3626;&#3640;&#3614;&#3619;&#3619;&#3603;&#3610;&#3640;&#3619;&#3637;)", "TH-84": "Surat Thani (&#3626;&#3640;&#3619;&#3634;&#3625;&#3598;&#3619;&#3660;&#3608;&#3634;&#3609;&#3637;)", "TH-32": "Surin (&#3626;&#3640;&#3619;&#3636;&#3609;&#3607;&#3619;&#3660;)", "TH-63": "Tak (&#3605;&#3634;&#3585;)", "TH-92": "Trang (&#3605;&#3619;&#3633;&#3591;)", "TH-23": "Trat (&#3605;&#3619;&#3634;&#3604;)", "TH-34": "Ubon Ratchathani (&#3629;&#3640;&#3610;&#3621;&#3619;&#3634;&#3594;&#3608;&#3634;&#3609;&#3637;)", "TH-41": "Udon Thani (&#3629;&#3640;&#3604;&#3619;&#3608;&#3634;&#3609;&#3637;)", "TH-61": "Uthai Thani (&#3629;&#3640;&#3607;&#3633;&#3618;&#3608;&#3634;&#3609;&#3637;)", "TH-53": "Uttaradit (&#3629;&#3640;&#3605;&#3619;&#3604;&#3636;&#3605;&#3606;&#3660;)", "TH-95": "Yala (&#3618;&#3632;&#3621;&#3634;)", "TH-35": "Yasothon (&#3618;&#3650;&#3626;&#3608;&#3619;)" }, "ES": { "C": "A Coru&ntilde;a", "VI": "Araba\/&Aacute;lava", "AB": "Albacete", "A": "Alicante", "AL": "Almer&iacute;a", "O": "Asturias", "AV": "&Aacute;vila", "BA": "Badajoz", "PM": "Baleares", "B": "Barcelona", "BU": "Burgos", "CC": "C&aacute;ceres", "CA": "C&aacute;diz", "S": "Cantabria", "CS": "Castell&oacute;n", "CE": "Ceuta", "CR": "Ciudad Real", "CO": "C&oacute;rdoba", "CU": "Cuenca", "GI": "Girona", "GR": "Granada", "GU": "Guadalajara", "SS": "Gipuzkoa", "H": "Huelva", "HU": "Huesca", "J": "Ja&eacute;n", "LO": "La Rioja", "GC": "Las Palmas", "LE": "Le&oacute;n", "L": "Lleida", "LU": "Lugo", "M": "Madrid", "MA": "M&aacute;laga", "ML": "Melilla", "MU": "Murcia", "NA": "Navarra", "OR": "Ourense", "P": "Palencia", "PO": "Pontevedra", "SA": "Salamanca", "TF": "Santa Cruz de Tenerife", "SG": "Segovia", "SE": "Sevilla", "SO": "Soria", "T": "Tarragona", "TE": "Teruel", "TO": "Toledo", "V": "Valencia", "VA": "Valladolid", "BI": "Bizkaia", "ZA": "Zamora", "Z": "Zaragoza" }, "HK": { "HONG KONG": "Hong Kong Island", "KOWLOON": "Kowloon", "NEW TERRITORIES": "New Territories" }, "NP": { "ILL": "Illam", "JHA": "Jhapa", "PAN": "Panchthar", "TAP": "Taplejung", "BHO": "Bhojpur", "DKA": "Dhankuta", "MOR": "Morang", "SUN": "Sunsari", "SAN": "Sankhuwa", "TER": "Terhathum", "KHO": "Khotang", "OKH": "Okhaldhunga", "SAP": "Saptari", "SIR": "Siraha", "SOL": "Solukhumbu", "UDA": "Udayapur", "DHA": "Dhanusa", "DLK": "Dolakha", "MOH": "Mohottari", "RAM": "Ramechha", "SAR": "Sarlahi", "SIN": "Sindhuli", "BHA": "Bhaktapur", "DHD": "Dhading", "KTM": "Kathmandu", "KAV": "Kavrepalanchowk", "LAL": "Lalitpur", "NUW": "Nuwakot", "RAS": "Rasuwa", "SPC": "Sindhupalchowk", "BAR": "Bara", "CHI": "Chitwan", "MAK": "Makwanpur", "PAR": "Parsa", "RAU": "Rautahat", "GOR": "Gorkha", "KAS": "Kaski", "LAM": "Lamjung", "MAN": "Manang", "SYN": "Syangja", "TAN": "Tanahun", "BAG": "Baglung", "PBT": "Parbat", "MUS": "Mustang", "MYG": "Myagdi", "AGR": "Agrghakanchi", "GUL": "Gulmi", "KAP": "Kapilbastu", "NAW": "Nawalparasi", "PAL": "Palpa", "RUP": "Rupandehi", "DAN": "Dang", "PYU": "Pyuthan", "ROL": "Rolpa", "RUK": "Rukum", "SAL": "Salyan", "BAN": "Banke", "BDA": "Bardiya", "DAI": "Dailekh", "JAJ": "Jajarkot", "SUR": "Surkhet", "DOL": "Dolpa", "HUM": "Humla", "JUM": "Jumla", "KAL": "Kalikot", "MUG": "Mugu", "ACH": "Achham", "BJH": "Bajhang", "BJU": "Bajura", "DOT": "Doti", "KAI": "Kailali", "BAI": "Baitadi", "DAD": "Dadeldhura", "DAR": "Darchula", "KAN": "Kanchanpur" }, "GR": { "I": "\u0391\u03c4\u03c4\u03b9\u03ba\u03ae", "A": "\u0391\u03bd\u03b1\u03c4\u03bf\u03bb\u03b9\u03ba\u03ae \u039c\u03b1\u03ba\u03b5\u03b4\u03bf\u03bd\u03af\u03b1 \u03ba\u03b1\u03b9 \u0398\u03c1\u03ac\u03ba\u03b7", "B": "\u039a\u03b5\u03bd\u03c4\u03c1\u03b9\u03ba\u03ae \u039c\u03b1\u03ba\u03b5\u03b4\u03bf\u03bd\u03af\u03b1", "C": "\u0394\u03c5\u03c4\u03b9\u03ba\u03ae \u039c\u03b1\u03ba\u03b5\u03b4\u03bf\u03bd\u03af\u03b1", "D": "\u0389\u03c0\u03b5\u03b9\u03c1\u03bf\u03c2", "E": "\u0398\u03b5\u03c3\u03c3\u03b1\u03bb\u03af\u03b1", "F": "\u0399\u03cc\u03bd\u03b9\u03bf\u03b9 \u039d\u03ae\u03c3\u03bf\u03b9", "G": "\u0394\u03c5\u03c4\u03b9\u03ba\u03ae \u0395\u03bb\u03bb\u03ac\u03b4\u03b1", "H": "\u03a3\u03c4\u03b5\u03c1\u03b5\u03ac \u0395\u03bb\u03bb\u03ac\u03b4\u03b1", "J": "\u03a0\u03b5\u03bb\u03bf\u03c0\u03cc\u03bd\u03bd\u03b7\u03c3\u03bf\u03c2", "K": "\u0392\u03cc\u03c1\u03b5\u03b9\u03bf \u0391\u03b9\u03b3\u03b1\u03af\u03bf", "L": "\u039d\u03cc\u03c4\u03b9\u03bf \u0391\u03b9\u03b3\u03b1\u03af\u03bf", "M": "\u039a\u03c1\u03ae\u03c4\u03b7" }, "MX": { "Distrito Federal": "Distrito Federal", "Jalisco": "Jalisco", "Nuevo Leon": "Nuevo Le\u00f3n", "Aguascalientes": "Aguascalientes", "Baja California": "Baja California", "Baja California Sur": "Baja California Sur", "Campeche": "Campeche", "Chiapas": "Chiapas", "Chihuahua": "Chihuahua", "Coahuila": "Coahuila", "Colima": "Colima", "Durango": "Durango", "Guanajuato": "Guanajuato", "Guerrero": "Guerrero", "Hidalgo": "Hidalgo", "Estado de Mexico": "Edo. de M\u00e9xico", "Michoacan": "Michoac\u00e1n", "Morelos": "Morelos", "Nayarit": "Nayarit", "Oaxaca": "Oaxaca", "Puebla": "Puebla", "Queretaro": "Quer\u00e9taro", "Quintana Roo": "Quintana Roo", "San Luis Potosi": "San Luis Potos\u00ed", "Sinaloa": "Sinaloa", "Sonora": "Sonora", "Tabasco": "Tabasco", "Tamaulipas": "Tamaulipas", "Tlaxcala": "Tlaxcala", "Veracruz": "Veracruz", "Yucatan": "Yucat\u00e1n", "Zacatecas": "Zacatecas" }, "BR": { "AC": "Acre", "AL": "Alagoas", "AP": "Amap&aacute;", "AM": "Amazonas", "BA": "Bahia", "CE": "Cear&aacute;", "DF": "Distrito Federal", "ES": "Esp&iacute;rito Santo", "GO": "Goi&aacute;s", "MA": "Maranh&atilde;o", "MT": "Mato Grosso", "MS": "Mato Grosso do Sul", "MG": "Minas Gerais", "PA": "Par&aacute;", "PB": "Para&iacute;ba", "PR": "Paran&aacute;", "PE": "Pernambuco", "PI": "Piau&iacute;", "RJ": "Rio de Janeiro", "RN": "Rio Grande do Norte", "RS": "Rio Grande do Sul", "RO": "Rond&ocirc;nia", "RR": "Roraima", "SC": "Santa Catarina", "SP": "S&atilde;o Paulo", "SE": "Sergipe", "TO": "Tocantins" }, "AR": { "C": "Ciudad Aut&oacute;noma de Buenos Aires", "B": "Buenos Aires", "K": "Catamarca", "H": "Chaco", "U": "Chubut", "X": "C&oacute;rdoba", "W": "Corrientes", "E": "Entre R&iacute;os", "P": "Formosa", "Y": "Jujuy", "L": "La Pampa", "F": "La Rioja", "M": "Mendoza", "N": "Misiones", "Q": "Neuqu&eacute;n", "R": "R&iacute;o Negro", "A": "Salta", "J": "San Juan", "D": "San Luis", "Z": "Santa Cruz", "S": "Santa Fe", "G": "Santiago del Estero", "V": "Tierra del Fuego", "T": "Tucum&aacute;n" }, "IT": { "AG": "Agrigento", "AL": "Alessandria", "AN": "Ancona", "AO": "Aosta", "AR": "Arezzo", "AP": "Ascoli Piceno", "AT": "Asti", "AV": "Avellino", "BA": "Bari", "BT": "Barletta-Andria-Trani", "BL": "Belluno", "BN": "Benevento", "BG": "Bergamo", "BI": "Biella", "BO": "Bologna", "BZ": "Bolzano", "BS": "Brescia", "BR": "Brindisi", "CA": "Cagliari", "CL": "Caltanissetta", "CB": "Campobasso", "CI": "Carbonia-Iglesias", "CE": "Caserta", "CT": "Catania", "CZ": "Catanzaro", "CH": "Chieti", "CO": "Como", "CS": "Cosenza", "CR": "Cremona", "KR": "Crotone", "CN": "Cuneo", "EN": "Enna", "FM": "Fermo", "FE": "Ferrara", "FI": "Firenze", "FG": "Foggia", "FC": "Forl\u00ec-Cesena", "FR": "Frosinone", "GE": "Genova", "GO": "Gorizia", "GR": "Grosseto", "IM": "Imperia", "IS": "Isernia", "SP": "La Spezia", "AQ": "L&apos;Aquila", "LT": "Latina", "LE": "Lecce", "LC": "Lecco", "LI": "Livorno", "LO": "Lodi", "LU": "Lucca", "MC": "Macerata", "MN": "Mantova", "MS": "Massa-Carrara", "MT": "Matera", "ME": "Messina", "MI": "Milano", "MO": "Modena", "MB": "Monza e della Brianza", "NA": "Napoli", "NO": "Novara", "NU": "Nuoro", "OT": "Olbia-Tempio", "OR": "Oristano", "PD": "Padova", "PA": "Palermo", "PR": "Parma", "PV": "Pavia", "PG": "Perugia", "PU": "Pesaro e Urbino", "PE": "Pescara", "PC": "Piacenza", "PI": "Pisa", "PT": "Pistoia", "PN": "Pordenone", "PZ": "Potenza", "PO": "Prato", "RG": "Ragusa", "RA": "Ravenna", "RC": "Reggio Calabria", "RE": "Reggio Emilia", "RI": "Rieti", "RN": "Rimini", "RM": "Roma", "RO": "Rovigo", "SA": "Salerno", "VS": "Medio Campidano", "SS": "Sassari", "SV": "Savona", "SI": "Siena", "SR": "Siracusa", "SO": "Sondrio", "TA": "Taranto", "TE": "Teramo", "TR": "Terni", "TO": "Torino", "OG": "Ogliastra", "TP": "Trapani", "TN": "Trento", "TV": "Treviso", "TS": "Trieste", "UD": "Udine", "VA": "Varese", "VE": "Venezia", "VB": "Verbano-Cusio-Ossola", "VC": "Vercelli", "VR": "Verona", "VV": "Vibo Valentia", "VI": "Vicenza", "VT": "Viterbo" }, "IN": { "AP": "Andhra Pradesh", "AR": "Arunachal Pradesh", "AS": "Assam", "BR": "Bihar", "CT": "Chhattisgarh", "GA": "Goa", "GJ": "Gujarat", "HR": "Haryana", "HP": "Himachal Pradesh", "JK": "Jammu and Kashmir", "JH": "Jharkhand", "KA": "Karnataka", "KL": "Kerala", "MP": "Madhya Pradesh", "MH": "Maharashtra", "MN": "Manipur", "ML": "Meghalaya", "MZ": "Mizoram", "NL": "Nagaland", "OR": "Orissa", "PB": "Punjab", "RJ": "Rajasthan", "SK": "Sikkim", "TN": "Tamil Nadu", "TS": "Telangana", "TR": "Tripura", "UK": "Uttarakhand", "UP": "Uttar Pradesh", "WB": "West Bengal", "AN": "Andaman and Nicobar Islands", "CH": "Chandigarh", "DN": "Dadar and Nagar Haveli", "DD": "Daman and Diu", "DL": "Delhi", "LD": "Lakshadeep", "PY": "Pondicherry (Puducherry)" }, "MY": { "JHR": "Johor", "KDH": "Kedah", "KTN": "Kelantan", "MLK": "Melaka", "NSN": "Negeri Sembilan", "PHG": "Pahang", "PRK": "Perak", "PLS": "Perlis", "PNG": "Pulau Pinang", "SBH": "Sabah", "SWK": "Sarawak", "SGR": "Selangor", "TRG": "Terengganu", "KUL": "W.P. Kuala Lumpur", "LBN": "W.P. Labuan", "PJY": "W.P. Putrajaya" }, "CN": { "CN1": "Yunnan \/ &#20113;&#21335;", "CN2": "Beijing \/ &#21271;&#20140;", "CN3": "Tianjin \/ &#22825;&#27941;", "CN4": "Hebei \/ &#27827;&#21271;", "CN5": "Shanxi \/ &#23665;&#35199;", "CN6": "Inner Mongolia \/ &#20839;&#33945;&#21476;", "CN7": "Liaoning \/ &#36797;&#23425;", "CN8": "Jilin \/ &#21513;&#26519;", "CN9": "Heilongjiang \/ &#40657;&#40857;&#27743;", "CN10": "Shanghai \/ &#19978;&#28023;", "CN11": "Jiangsu \/ &#27743;&#33487;", "CN12": "Zhejiang \/ &#27993;&#27743;", "CN13": "Anhui \/ &#23433;&#24509;", "CN14": "Fujian \/ &#31119;&#24314;", "CN15": "Jiangxi \/ &#27743;&#35199;", "CN16": "Shandong \/ &#23665;&#19996;", "CN17": "Henan \/ &#27827;&#21335;", "CN18": "Hubei \/ &#28246;&#21271;", "CN19": "Hunan \/ &#28246;&#21335;", "CN20": "Guangdong \/ &#24191;&#19996;", "CN21": "Guangxi Zhuang \/ &#24191;&#35199;&#22766;&#26063;", "CN22": "Hainan \/ &#28023;&#21335;", "CN23": "Chongqing \/ &#37325;&#24198;", "CN24": "Sichuan \/ &#22235;&#24029;", "CN25": "Guizhou \/ &#36149;&#24030;", "CN26": "Shaanxi \/ &#38485;&#35199;", "CN27": "Gansu \/ &#29976;&#32899;", "CN28": "Qinghai \/ &#38738;&#28023;", "CN29": "Ningxia Hui \/ &#23425;&#22799;", "CN30": "Macau \/ &#28595;&#38376;", "CN31": "Tibet \/ &#35199;&#34255;", "CN32": "Xinjiang \/ &#26032;&#30086;" }, "PE": { "CAL": "El Callao", "LMA": "Municipalidad Metropolitana de Lima", "AMA": "Amazonas", "ANC": "Ancash", "APU": "Apur&iacute;mac", "ARE": "Arequipa", "AYA": "Ayacucho", "CAJ": "Cajamarca", "CUS": "Cusco", "HUV": "Huancavelica", "HUC": "Hu&aacute;nuco", "ICA": "Ica", "JUN": "Jun&iacute;n", "LAL": "La Libertad", "LAM": "Lambayeque", "LIM": "Lima", "LOR": "Loreto", "MDD": "Madre de Dios", "MOQ": "Moquegua", "PAS": "Pasco", "PIU": "Piura", "PUN": "Puno", "SAM": "San Mart&iacute;n", "TAC": "Tacna", "TUM": "Tumbes", "UCA": "Ucayali" }, "AU": { "ACT": "Australian Capital Territory", "NSW": "New South Wales", "NT": "Northern Territory", "QLD": "Queensland", "SA": "South Australia", "TAS": "Tasmania", "VIC": "Victoria", "WA": "Western Australia" }, "PH": { "ABR": "Abra", "AGN": "Agusan del Norte", "AGS": "Agusan del Sur", "AKL": "Aklan", "ALB": "Albay", "ANT": "Antique", "APA": "Apayao", "AUR": "Aurora", "BAS": "Basilan", "BAN": "Bataan", "BTN": "Batanes", "BTG": "Batangas", "BEN": "Benguet", "BIL": "Biliran", "BOH": "Bohol", "BUK": "Bukidnon", "BUL": "Bulacan", "CAG": "Cagayan", "CAN": "Camarines Norte", "CAS": "Camarines Sur", "CAM": "Camiguin", "CAP": "Capiz", "CAT": "Catanduanes", "CAV": "Cavite", "CEB": "Cebu", "COM": "Compostela Valley", "NCO": "Cotabato", "DAV": "Davao del Norte", "DAS": "Davao del Sur", "DAC": "Davao Occidental", "DAO": "Davao Oriental", "DIN": "Dinagat Islands", "EAS": "Eastern Samar", "GUI": "Guimaras", "IFU": "Ifugao", "ILN": "Ilocos Norte", "ILS": "Ilocos Sur", "ILI": "Iloilo", "ISA": "Isabela", "KAL": "Kalinga", "LUN": "La Union", "LAG": "Laguna", "LAN": "Lanao del Norte", "LAS": "Lanao del Sur", "LEY": "Leyte", "MAG": "Maguindanao", "MAD": "Marinduque", "MAS": "Masbate", "MSC": "Misamis Occidental", "MSR": "Misamis Oriental", "MOU": "Mountain Province", "NEC": "Negros Occidental", "NER": "Negros Oriental", "NSA": "Northern Samar", "NUE": "Nueva Ecija", "NUV": "Nueva Vizcaya", "MDC": "Occidental Mindoro", "MDR": "Oriental Mindoro", "PLW": "Palawan", "PAM": "Pampanga", "PAN": "Pangasinan", "QUE": "Quezon", "QUI": "Quirino", "RIZ": "Rizal", "ROM": "Romblon", "WSA": "Samar", "SAR": "Sarangani", "SIQ": "Siquijor", "SOR": "Sorsogon", "SCO": "South Cotabato", "SLE": "Southern Leyte", "SUK": "Sultan Kudarat", "SLU": "Sulu", "SUN": "Surigao del Norte", "SUR": "Surigao del Sur", "TAR": "Tarlac", "TAW": "Tawi-Tawi", "ZMB": "Zambales", "ZAN": "Zamboanga del Norte", "ZAS": "Zamboanga del Sur", "ZSI": "Zamboanga Sibugay", "00": "Metro Manila" }, "NZ": { "NL": "Northland", "AK": "Auckland", "WA": "Waikato", "BP": "Bay of Plenty", "TK": "Taranaki", "GI": "Gisborne", "HB": "Hawke&rsquo;s Bay", "MW": "Manawatu-Wanganui", "WE": "Wellington", "NS": "Nelson", "MB": "Marlborough", "TM": "Tasman", "WC": "West Coast", "CT": "Canterbury", "OT": "Otago", "SL": "Southland" }, "BD": { "BAG": "Bagerhat", "BAN": "Bandarban", "BAR": "Barguna", "BARI": "Barisal", "BHO": "Bhola", "BOG": "Bogra", "BRA": "Brahmanbaria", "CHA": "Chandpur", "CHI": "Chittagong", "CHU": "Chuadanga", "COM": "Comilla", "COX": "Cox's Bazar", "DHA": "Dhaka", "DIN": "Dinajpur", "FAR": "Faridpur ", "FEN": "Feni", "GAI": "Gaibandha", "GAZI": "Gazipur", "GOP": "Gopalganj", "HAB": "Habiganj", "JAM": "Jamalpur", "JES": "Jessore", "JHA": "Jhalokati", "JHE": "Jhenaidah", "JOY": "Joypurhat", "KHA": "Khagrachhari", "KHU": "Khulna", "KIS": "Kishoreganj", "KUR": "Kurigram", "KUS": "Kushtia", "LAK": "Lakshmipur", "LAL": "Lalmonirhat", "MAD": "Madaripur", "MAG": "Magura", "MAN": "Manikganj ", "MEH": "Meherpur", "MOU": "Moulvibazar", "MUN": "Munshiganj", "MYM": "Mymensingh", "NAO": "Naogaon", "NAR": "Narail", "NARG": "Narayanganj", "NARD": "Narsingdi", "NAT": "Natore", "NAW": "Nawabganj", "NET": "Netrakona", "NIL": "Nilphamari", "NOA": "Noakhali", "PAB": "Pabna", "PAN": "Panchagarh", "PAT": "Patuakhali", "PIR": "Pirojpur", "RAJB": "Rajbari", "RAJ": "Rajshahi", "RAN": "Rangamati", "RANP": "Rangpur", "SAT": "Satkhira", "SHA": "Shariatpur", "SHE": "Sherpur", "SIR": "Sirajganj", "SUN": "Sunamganj", "SYL": "Sylhet", "TAN": "Tangail", "THA": "Thakurgaon" }, "JP": { "JP01": "Hokkaido", "JP02": "Aomori", "JP03": "Iwate", "JP04": "Miyagi", "JP05": "Akita", "JP06": "Yamagata", "JP07": "Fukushima", "JP08": "Ibaraki", "JP09": "Tochigi", "JP10": "Gunma", "JP11": "Saitama", "JP12": "Chiba", "JP13": "Tokyo", "JP14": "Kanagawa", "JP15": "Niigata", "JP16": "Toyama", "JP17": "Ishikawa", "JP18": "Fukui", "JP19": "Yamanashi", "JP20": "Nagano", "JP21": "Gifu", "JP22": "Shizuoka", "JP23": "Aichi", "JP24": "Mie", "JP25": "Shiga", "JP26": "Kyoto", "JP27": "Osaka", "JP28": "Hyogo", "JP29": "Nara", "JP30": "Wakayama", "JP31": "Tottori", "JP32": "Shimane", "JP33": "Okayama", "JP34": "Hiroshima", "JP35": "Yamaguchi", "JP36": "Tokushima", "JP37": "Kagawa", "JP38": "Ehime", "JP39": "Kochi", "JP40": "Fukuoka", "JP41": "Saga", "JP42": "Nagasaki", "JP43": "Kumamoto", "JP44": "Oita", "JP45": "Miyazaki", "JP46": "Kagoshima", "JP47": "Okinawa" }, "CA": { "AB": "Alberta", "BC": "British Columbia", "MB": "Manitoba", "NB": "New Brunswick", "NL": "Newfoundland and Labrador", "NT": "Northwest Territories", "NS": "Nova Scotia", "NU": "Nunavut", "ON": "Ontario", "PE": "Prince Edward Island", "QC": "Quebec", "SK": "Saskatchewan", "YT": "Yukon Territory" }, "RO": { "AB": "Alba", "AR": "Arad", "AG": "Arge&#537;", "BC": "Bac&#259;u", "BH": "Bihor", "BN": "Bistri&#539;a-N&#259;s&#259;ud", "BT": "Boto&#537;ani", "BR": "Br&#259;ila", "BV": "Bra&#537;ov", "B": "Bucure&#537;ti", "BZ": "Buz&#259;u", "CL": "C&#259;l&#259;ra&#537;i", "CS": "Cara&#537;-Severin", "CJ": "Cluj", "CT": "Constan&#539;a", "CV": "Covasna", "DB": "D&acirc;mbovi&#539;a", "DJ": "Dolj", "GL": "Gala&#539;i", "GR": "Giurgiu", "GJ": "Gorj", "HR": "Harghita", "HD": "Hunedoara", "IL": "Ialomi&#539;a", "IS": "Ia&#537;i", "IF": "Ilfov", "MM": "Maramure&#537;", "MH": "Mehedin&#539;i", "MS": "Mure&#537;", "NT": "Neam&#539;", "OT": "Olt", "PH": "Prahova", "SJ": "S&#259;laj", "SM": "Satu Mare", "SB": "Sibiu", "SV": "Suceava", "TR": "Teleorman", "TM": "Timi&#537;", "TL": "Tulcea", "VL": "V&acirc;lcea", "VS": "Vaslui", "VN": "Vrancea" }, "US": { "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "DC": "District Of Columbia", "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York", "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming", "AA": "Armed Forces (AA)", "AE": "Armed Forces (AE)", "AP": "Armed Forces (AP)", "AS": "American Samoa", "GU": "Guam", "MP": "Northern Mariana Islands", "PR": "Puerto Rico", "UM": "US Minor Outlying Islands", "VI": "US Virgin Islands" }, "TR": { "TR01": "Adana", "TR02": "Ad&#305;yaman", "TR03": "Afyon", "TR04": "A&#287;r&#305;", "TR05": "Amasya", "TR06": "Ankara", "TR07": "Antalya", "TR08": "Artvin", "TR09": "Ayd&#305;n", "TR10": "Bal&#305;kesir", "TR11": "Bilecik", "TR12": "Bing&#246;l", "TR13": "Bitlis", "TR14": "Bolu", "TR15": "Burdur", "TR16": "Bursa", "TR17": "&#199;anakkale", "TR18": "&#199;ank&#305;r&#305;", "TR19": "&#199;orum", "TR20": "Denizli", "TR21": "Diyarbak&#305;r", "TR22": "Edirne", "TR23": "Elaz&#305;&#287;", "TR24": "Erzincan", "TR25": "Erzurum", "TR26": "Eski&#351;ehir", "TR27": "Gaziantep", "TR28": "Giresun", "TR29": "G&#252;m&#252;&#351;hane", "TR30": "Hakkari", "TR31": "Hatay", "TR32": "Isparta", "TR33": "&#304;&#231;el", "TR34": "&#304;stanbul", "TR35": "&#304;zmir", "TR36": "Kars", "TR37": "Kastamonu", "TR38": "Kayseri", "TR39": "K&#305;rklareli", "TR40": "K&#305;r&#351;ehir", "TR41": "Kocaeli", "TR42": "Konya", "TR43": "K&#252;tahya", "TR44": "Malatya", "TR45": "Manisa", "TR46": "Kahramanmara&#351;", "TR47": "Mardin", "TR48": "Mu&#287;la", "TR49": "Mu&#351;", "TR50": "Nev&#351;ehir", "TR51": "Ni&#287;de", "TR52": "Ordu", "TR53": "Rize", "TR54": "Sakarya", "TR55": "Samsun", "TR56": "Siirt", "TR57": "Sinop", "TR58": "Sivas", "TR59": "Tekirda&#287;", "TR60": "Tokat", "TR61": "Trabzon", "TR62": "Tunceli", "TR63": "&#350;anl&#305;urfa", "TR64": "U&#351;ak", "TR65": "Van", "TR66": "Yozgat", "TR67": "Zonguldak", "TR68": "Aksaray", "TR69": "Bayburt", "TR70": "Karaman", "TR71": "K&#305;r&#305;kkale", "TR72": "Batman", "TR73": "&#350;&#305;rnak", "TR74": "Bart&#305;n", "TR75": "Ardahan", "TR76": "I&#287;d&#305;r", "TR77": "Yalova", "TR78": "Karab&#252;k", "TR79": "Kilis", "TR80": "Osmaniye", "TR81": "D&#252;zce" }, "IR": { "KHZ": "Khuzestan  (\u062e\u0648\u0632\u0633\u062a\u0627\u0646)", "THR": "Tehran  (\u062a\u0647\u0631\u0627\u0646)", "ILM": "Ilaam (\u0627\u06cc\u0644\u0627\u0645)", "BHR": "Bushehr (\u0628\u0648\u0634\u0647\u0631)", "ADL": "Ardabil (\u0627\u0631\u062f\u0628\u06cc\u0644)", "ESF": "Isfahan (\u0627\u0635\u0641\u0647\u0627\u0646)", "YZD": "Yazd (\u06cc\u0632\u062f)", "KRH": "Kermanshah (\u06a9\u0631\u0645\u0627\u0646\u0634\u0627\u0647)", "KRN": "Kerman (\u06a9\u0631\u0645\u0627\u0646)", "HDN": "Hamadan (\u0647\u0645\u062f\u0627\u0646)", "GZN": "Ghazvin (\u0642\u0632\u0648\u06cc\u0646)", "ZJN": "Zanjan (\u0632\u0646\u062c\u0627\u0646)", "LRS": "Luristan (\u0644\u0631\u0633\u062a\u0627\u0646)", "ABZ": "Alborz (\u0627\u0644\u0628\u0631\u0632)", "EAZ": "East Azarbaijan (\u0622\u0630\u0631\u0628\u0627\u06cc\u062c\u0627\u0646 \u0634\u0631\u0642\u06cc)", "WAZ": "West Azarbaijan (\u0622\u0630\u0631\u0628\u0627\u06cc\u062c\u0627\u0646 \u063a\u0631\u0628\u06cc)", "CHB": "Chaharmahal and Bakhtiari (\u0686\u0647\u0627\u0631\u0645\u062d\u0627\u0644 \u0648 \u0628\u062e\u062a\u06cc\u0627\u0631\u06cc)", "SKH": "South Khorasan (\u062e\u0631\u0627\u0633\u0627\u0646 \u062c\u0646\u0648\u0628\u06cc)", "RKH": "Razavi Khorasan (\u062e\u0631\u0627\u0633\u0627\u0646 \u0631\u0636\u0648\u06cc)", "NKH": "North Khorasan (\u062e\u0631\u0627\u0633\u0627\u0646 \u062c\u0646\u0648\u0628\u06cc)", "SMN": "Semnan (\u0633\u0645\u0646\u0627\u0646)", "FRS": "Fars (\u0641\u0627\u0631\u0633)", "QHM": "Qom (\u0642\u0645)", "KRD": "Kurdistan \/ \u06a9\u0631\u062f\u0633\u062a\u0627\u0646)", "KBD": "Kohgiluyeh and BoyerAhmad (\u06a9\u0647\u06af\u06cc\u0644\u0648\u06cc\u06cc\u0647 \u0648 \u0628\u0648\u06cc\u0631\u0627\u062d\u0645\u062f)", "GLS": "Golestan (\u06af\u0644\u0633\u062a\u0627\u0646)", "GIL": "Gilan (\u06af\u06cc\u0644\u0627\u0646)", "MZN": "Mazandaran (\u0645\u0627\u0632\u0646\u062f\u0631\u0627\u0646)", "MKZ": "Markazi (\u0645\u0631\u06a9\u0632\u06cc)", "HRZ": "Hormozgan (\u0647\u0631\u0645\u0632\u06af\u0627\u0646)", "SBN": "Sistan and Baluchestan (\u0633\u06cc\u0633\u062a\u0627\u0646 \u0648 \u0628\u0644\u0648\u0686\u0633\u062a\u0627\u0646)" }, "ID": { "AC": "Daerah Istimewa Aceh", "SU": "Sumatera Utara", "SB": "Sumatera Barat", "RI": "Riau", "KR": "Kepulauan Riau", "JA": "Jambi", "SS": "Sumatera Selatan", "BB": "Bangka Belitung", "BE": "Bengkulu", "LA": "Lampung", "JK": "DKI Jakarta", "JB": "Jawa Barat", "BT": "Banten", "JT": "Jawa Tengah", "JI": "Jawa Timur", "YO": "Daerah Istimewa Yogyakarta", "BA": "Bali", "NB": "Nusa Tenggara Barat", "NT": "Nusa Tenggara Timur", "KB": "Kalimantan Barat", "KT": "Kalimantan Tengah", "KI": "Kalimantan Timur", "KS": "Kalimantan Selatan", "KU": "Kalimantan Utara", "SA": "Sulawesi Utara", "ST": "Sulawesi Tengah", "SG": "Sulawesi Tenggara", "SR": "Sulawesi Barat", "SN": "Sulawesi Selatan", "GO": "Gorontalo", "MA": "Maluku", "MU": "Maluku Utara", "PA": "Papua", "PB": "Papua Barat" }, "IE": { "CW": "Carlow", "CN": "Cavan", "CE": "Clare", "CO": "Cork", "DL": "Donegal", "D": "Dublin", "G": "Galway", "KY": "Kerry", "KE": "Kildare", "KK": "Kilkenny", "LS": "Laois", "LM": "Leitrim", "LK": "Limerick", "LD": "Longford", "LH": "Louth", "MO": "Mayo", "MH": "Meath", "MN": "Monaghan", "OY": "Offaly", "RN": "Roscommon", "SO": "Sligo", "TA": "Tipperary", "WD": "Waterford", "WH": "Westmeath", "WX": "Wexford", "WW": "Wicklow" } };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/paid-member-subscriptions/assets/js/front-end946b.js?ver=2.12.3"
		id="pms-front-end-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min11d9.js?ver=3.21.3"
		id="elementor-pro-webpack-runtime-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/webpack.runtime.min3cad.js?ver=3.21.8"
		id="elementor-webpack-runtime-js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/frontend-modules.min3cad.js?ver=3.21.8"
		id="elementor-frontend-modules-js"></script>
	<script type="text/javascript" id="elementor-pro-frontend-js-before">
		/* <![CDATA[ */
		var ElementorProFrontendConfig = { "ajaxurl": "https:\/\/earntv.io\/wp-admin\/admin-ajax.php", "nonce": "d13461719d", "urls": { "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor-pro\/assets\/", "rest": "https:\/\/earntv.io\/wp-json\/" }, "shareButtonsNetworks": { "facebook": { "title": "Facebook", "has_counter": true }, "twitter": { "title": "Twitter" }, "linkedin": { "title": "LinkedIn", "has_counter": true }, "pinterest": { "title": "Pinterest", "has_counter": true }, "reddit": { "title": "Reddit", "has_counter": true }, "vk": { "title": "VK", "has_counter": true }, "odnoklassniki": { "title": "OK", "has_counter": true }, "tumblr": { "title": "Tumblr" }, "digg": { "title": "Digg" }, "skype": { "title": "Skype" }, "stumbleupon": { "title": "StumbleUpon", "has_counter": true }, "mix": { "title": "Mix" }, "telegram": { "title": "Telegram" }, "pocket": { "title": "Pocket", "has_counter": true }, "xing": { "title": "XING", "has_counter": true }, "whatsapp": { "title": "WhatsApp" }, "email": { "title": "Email" }, "print": { "title": "Print" }, "x-twitter": { "title": "X" }, "threads": { "title": "Threads" } }, "facebook_sdk": { "lang": "en_US", "app_id": "" }, "lottie": { "defaultAnimationUrl": "https:\/\/earntv.io\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json" } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor-pro/assets/js/frontend.min11d9.js?ver=3.21.3"
		id="elementor-pro-frontend-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2"
		id="elementor-waypoints-js"></script>
	<script type="text/javascript" id="elementor-frontend-js-before">
		/* <![CDATA[ */
		var elementorFrontendConfig = { "environmentMode": { "edit": false, "wpPreview": false, "isScriptDebug": false }, "i18n": { "shareOnFacebook": "Share on Facebook", "shareOnTwitter": "Share on Twitter", "pinIt": "Pin it", "download": "Download", "downloadImage": "Download image", "fullscreen": "Fullscreen", "zoom": "Zoom", "share": "Share", "playVideo": "Play Video", "previous": "Previous", "next": "Next", "close": "Close", "a11yCarouselWrapperAriaLabel": "Carousel | Horizontal scrolling: Arrow Left & Right", "a11yCarouselPrevSlideMessage": "Previous slide", "a11yCarouselNextSlideMessage": "Next slide", "a11yCarouselFirstSlideMessage": "This is the first slide", "a11yCarouselLastSlideMessage": "This is the last slide", "a11yCarouselPaginationBulletMessage": "Go to slide" }, "is_rtl": false, "breakpoints": { "xs": 0, "sm": 480, "md": 768, "lg": 1025, "xl": 1440, "xxl": 1600 }, "responsive": { "breakpoints": { "mobile": { "label": "Mobile Portrait", "value": 767, "default_value": 767, "direction": "max", "is_enabled": true }, "mobile_extra": { "label": "Mobile Landscape", "value": 880, "default_value": 880, "direction": "max", "is_enabled": false }, "tablet": { "label": "Tablet Portrait", "value": 1024, "default_value": 1024, "direction": "max", "is_enabled": true }, "tablet_extra": { "label": "Tablet Landscape", "value": 1200, "default_value": 1200, "direction": "max", "is_enabled": false }, "laptop": { "label": "Laptop", "value": 1366, "default_value": 1366, "direction": "max", "is_enabled": false }, "widescreen": { "label": "Widescreen", "value": 2400, "default_value": 2400, "direction": "min", "is_enabled": false } } }, "version": "3.21.8", "is_static": false, "experimentalFeatures": { "e_optimized_assets_loading": true, "e_optimized_css_loading": true, "e_font_icon_svg": true, "additional_custom_breakpoints": true, "container": true, "e_swiper_latest": true, "e_optimized_control_loading": true, "theme_builder_v2": true, "home_screen": true, "landing-pages": true, "nested-elements": true, "e_lazyload": true, "form-submissions": true }, "urls": { "assets": "https:\/\/earntv.io\/wp-content\/plugins\/elementor\/assets\/" }, "swiperClass": "swiper", "settings": { "page": [], "editorPreferences": [] }, "kit": { "active_breakpoints": ["viewport_mobile", "viewport_tablet"], "global_image_lightbox": "yes", "lightbox_enable_counter": "yes", "lightbox_enable_fullscreen": "yes", "lightbox_enable_zoom": "yes", "lightbox_enable_share": "yes", "lightbox_title_src": "title", "lightbox_description_src": "description" }, "post": { "id": 17024, "title": "EarnTV%20-%20Watch%20%26%20Earn", "excerpt": "", "featuredImage": "https:\/\/earntv.io\/wp-content\/uploads\/2024\/06\/microprocessor.png" } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?=base_url()?>assets/wp-content/plugins/elementor/assets/js/frontend.min3cad.js?ver=3.21.8"
		id="elementor-frontend-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min11d9.js?ver=3.21.3"
		id="pro-elements-handlers-js"></script>
	<script type="text/javascript"
		src="<?=base_url()?>assets/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min11d9.js?ver=3.21.3"
		id="e-sticky-js"></script>
	<script>
		var adminajaxurl = "wp-admin/admin-ajax.html";
		if (document.getElementById("wp-admin-bar-lwsop-clear-cache") != null) {
			document.getElementById("wp-admin-bar-lwsop-clear-cache").addEventListener('click', function () {
				jQuery.ajax({
					url: adminajaxurl,
					type: "POST",
					dataType: 'json',
					timeout: 120000,
					context: document.body,
					data: {
						action: "lws_clear_fb_cache",
						_ajax_nonce: '1eae7fff7c'
					},
					success: function (data) {
						switch (data['code']) {
							case 'SUCCESS':
								alert("Cache deleted");
								break;
							default:
								alert("Cache not deleted");
								break;
						}
					},
					error: function (error) {
						console.log(error);
					}
				});
			});
		}
		if (document.getElementById("wp-admin-bar-lwsop-clear-subcache") != null) {
			document.getElementById("wp-admin-bar-lwsop-clear-subcache").addEventListener('click', function () {
				jQuery.ajax({
					url: adminajaxurl,
					type: "POST",
					dataType: 'json',
					timeout: 120000,
					context: document.body,
					data: {
						action: "lws_clear_style_fb_cache",
						_ajax_nonce: 'd1e34bbdab'
					},
					success: function (data) {
						switch (data['code']) {
							case 'SUCCESS':
								alert("Cache deleted");
								break;
							default:
								alert("Cache not deleted");
								break;
						}
					},
					error: function (error) {
						console.log(error);
					}
				});
			});
		}
		if (document.getElementById("wp-admin-bar-lwsop-clear-htmlcache") != null) {
			document.getElementById("wp-admin-bar-lwsop-clear-htmlcache").addEventListener('click', function () {
				jQuery.ajax({
					url: adminajaxurl,
					dataType: 'json',
					type: "POST",
					timeout: 120000,
					context: document.body,
					data: {
						action: "lws_clear_html_fb_cache",
						_ajax_nonce: '6e47e9baf3'
					},
					success: function (data) {
						switch (data['code']) {
							case 'SUCCESS':
								alert("Cache deleted");
								break;
							default:
								alert("Cache not deleted");
								break;
						}
					},
					error: function (error) {
						console.log(error);
					}
				});
			});
		}
		if (document.getElementById("wp-admin-bar-lwsop-clear-current-cache") != null) {
			document.getElementById("wp-admin-bar-lwsop-clear-current-cache").addEventListener('click', function () {
				jQuery.ajax({
					url: adminajaxurl,
					dataType: 'json',
					type: "POST",
					timeout: 120000,
					context: document.body,
					data: {
						action: "lws_clear_currentpage_fb_cache",
						_ajax_nonce: 'db0d3afa1d',
						request_uri: '/'
					},
					success: function (data) {
						switch (data['code']) {
							case 'SUCCESS':
								alert("Cache deleted");
								break;
							default:
								alert("Cache not deleted");
								break;
						}
					},
					error: function (error) {
						console.log(error);
					}
				});
			});
		}
	</script>

	<script type="text/javascript">

		var debounce_fn = _.debounce(fetchResults, 500, false);



		function fetchResults(input) {

			let keyword = input.value;

			if (jQuery(input).parents('header').length == 0) {

				return false

			}

			if (keyword == "") {

				jQuery(input).siblings('.datafetch').html('');

			} else {

				jQuery.ajax({

					url: 'https://earntv.io/wp-admin/admin-ajax.php',

					type: 'post',

					data: {

						action: 'data_fetch',

						keyword: keyword,

						is_include: 'posts',

					},

					success: function (data) {

						jQuery(input).siblings('.datafetch').html(data);

					}

				});

			}

		}

	</script>


</body>



</html>