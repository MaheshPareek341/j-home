<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 $config['service_type'] = array(
            'influencer-marketing'	=>	'Influencer Marketing' ,
            'performance-marketing'	=>	'Performance Marketing' ,
            'content-creation'	=>	'Content Creation' ,
            'social-media-management'	=>	'Social Media Management' ,
            'public-relations'	=>	'Public Relations' ,
            'media-buying'	=>	'Media Buying' ,
            'meme-marketing'	=>	'Meme Marketing',
            'artist-management'	=>	'Artist Management',
            'music-events'	=>	'Music Events',
            );