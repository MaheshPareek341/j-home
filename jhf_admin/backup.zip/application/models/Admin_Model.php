<?php  
    class Admin_model extends CI_Model  
    {  
        function admin_login($username, $password)  
        {  
            $this->db->where('username', $username);  
            $this->db->where('password', $password);  
            $query = $this->db->get('admins');  
           
            if($query->num_rows() > 0)  
            {  
                return true;  
            }  
            else  
            {  
                return false;       
            }  
        }
        
        public function create_user($data) {
            return $this->db->insert('users', $data);
        }
        
        function getTotalCategoryCount(){
            return $this->db->from("category")->where('cat_status',1)->count_all_results();
        }
        
        function getTotalSongsCount(){
            return $this->db->from("songs")->where('song_status', 1)->count_all_results();
        }
        
        function getAllTrustees(){
            return $this->db->select("*")->get('trustees')->result();
        }
        
        public function add_trustees($data) {
            return $this->db->insert('trustees', $data);
        }
        
        public function update_trustees($id, $data) {
            $this->db->where('id', $id);
            return $this->db->update('trustees', $data);
        }
        
        public function delete_trustees($id) {
            return $this->db->delete('trustees', array('id' => $id));
        }
        
        function getAllCommitee(){
            return $this->db->select("*")->get('commitee')->result();
        }
        
        public function add_commitee($data) {
            return $this->db->insert('commitee', $data);
        }
        
        public function update_commitee($id, $data) {
            $this->db->where('id', $id);
            return $this->db->update('commitee', $data);
        }
        
        public function delete_commitee($id) {
            return $this->db->delete('commitee', array('id' => $id));
        }
        
        public function get_commitee_by_id($id) {
            return $this->db->get_where('commitee', ['id' => $id])->row_array();
        }
        
        public function get_trustees_by_id($id) {
            return $this->db->get_where('trustees', ['id' => $id])->row_array();
        }
        
        
        public function getAllGallery(){
            return $this->db->select("*")
                 ->from('gallery')
                 ->get()
                 ->result();
        }
        
        public function add_image($data) {
            return $this->db->insert('gallery', $data);
        }
        
        public function update_image($id, $data) {
            $this->db->where('id', $id);
            return $this->db->update('gallery', $data);
        }
        
        public function delete_image($id) {
            return $this->db->delete('gallery', array('id' => $id));
        }
        
        public function get_image_by_id($id) {
            return $this->db->get_where('gallery', ['id' => $id])->row_array();
        }

        
        public function update_user($id, $data) {
          
            $this->db->where('user_id', $id);
            return $this->db->update('users', $data);
        }
        
        public function delete_user($id) {
            return $this->db->delete('users', array('user_id' => $id));
        }
        
        public function get_user_by_id($user_id) {
            return $this->db->get_where('users', ['user_id' => $user_id])->row_array();
        }
        
    }
?>