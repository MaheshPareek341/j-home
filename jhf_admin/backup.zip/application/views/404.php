<?php include "common/header.php" ?>
<div class="indx_title_main_wrapper">
	<div class="title_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="indx_title_left_wrapper m24_cover">
					<h2>404 error</h2>

					<ul>
						<li><a href="<?=base_url()?>">Home</a> &nbsp;&nbsp;&nbsp;/</li>
						<li>404 error</li>
					</ul>

				</div>

			</div>
		</div>
	</div>
</div>

<div class="error_wrapper m24_cover">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">                 
			<img src="<?=base_url()?>assets/images/error.png" alt="img" class="img-responsive">               
				<div class="error_page_cntnt m24_cover">
					<h3>Sorry, This Page Isn't available :(</h3>
					<p>This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. A Aenean sollicitudin, lorem quis bibend Aenean sollicitudin, lorem . 
					</p>
					<div class="lang_apply_btn home_btn m24_cover">
						<ul>
						<li>
							<a href="<?=base_url()?>">home page</a>
						</li>
					</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include "common/footer.php"; ?>