<?php include("common/header.php"); ?>


      <main id="main" class="main">
         <div class="pagetitle">
            <h1>Videos</h1>
            <nav>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?=base_url()?>admin/dashboard">Home</a></li>
                  <li class="breadcrumb-item active"><a href="<?=base_url()?>admin/songs">Videos</a></li>
                  <li class="breadcrumb-item active">Edit</li>
               </ol>
            </nav>
         </div>
         <!-- End Page Title --> 
         <section class="section dashboard">

                <?php if ($this->session->flashdata('message')): ?>
                    <div class="alert <?= $this->session->flashdata('message_type') === 'success' ? 'alert-success' : 'alert-danger' ?>">
                        <?= $this->session->flashdata('message') ?>
                    </div>
                <?php endif; ?>
                
            <div class="row">
               
                <div class="col-md-12">
                    <div class="my-listing-table-wrapper">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade active show" id="active" role="tabpanel" aria-labelledby="active-tab">
                    
                                <form action="<?= base_url('admin/songs/update/'.$song['song_id']); ?>" method="post">
                                     <div class="form-group">
                                        <label for="song_name">Video Name</label>
                                        <input type="text" class="form-control mt-1" id="song_name" name="song_name" value="<?= $song['song_name']; ?>" required>
                                    </div>
                            
                                    <div class="form-group pt-3">
                                        <label for="youtube_url">YouTube URL (https://www.youtube.com/embed/VIDEO_ID)</label>
                                        <input type="text" class="form-control mt-1" id="youtube_url" name="youtube_url" value="<?= $song['youtube_url']; ?>" required>
                                    </div>
                            
                                    <div class="form-group pt-3">
                                        <label for="song_url">Video URL</label>
                                        <input type="text" class="form-control mt-1" id="song_url" name="song_url" value="<?= $song['song_url']; ?>" required>
                                    </div>
                            
                                    <div class="form-group pt-3">
                                        <label for="cat_id">Category</label>
                                        <select class="form-control mt-1" id="cat_id" name="cat_id" required>
                                            <option value="">Select Category</option>
                                            <?php foreach ($category as $cat): ?>
                                                <option value="<?= $cat->cat_id; ?>" <?= $song['cat_id'] == $cat->cat_id ? 'selected' : ''; ?>>
                                                    <?= $cat->cat_name; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                            
                                    <div class="form-group pt-3">
                                        <label for="treanding_song">Trending Video</label>
                                        <input type="checkbox" name="treanding_song" id="treanding_song" value="1" <?= $song['treanding_song'] ? 'checked' : ''; ?>>
                                    </div>
                            
                                    <div class="form-group pt-3">
                                        <label for="top_song">Top Video</label>
                                        <input type="checkbox" name="top_song" id="top_song" value="1" <?= $song['top_song'] ? 'checked' : ''; ?>>
                                    </div>
                            
                                    <div class="form-group pt-3">
                                        <label for="featured_song">Featured Video</label>
                                        <input type="checkbox" name="featured_song" id="featured_song" value="1" <?= $song['featured_song'] ? 'checked' : ''; ?>>
                                    </div>
                            
                                    <div class="form-group pt-3 pb-3">
                                        <label for="new_release_song">New Release Video</label>
                                        <input type="checkbox" name="new_release_song" id="new_release_song" value="1" <?= $song['new_release_song'] ? 'checked' : ''; ?>>
                                    </div>
                            
                                    <button type="submit" class="btn btn-primary">Update Video</button>
                                </form>

                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>
      </main>
     
        
        
    </div>

<?php include("common/footer.php"); ?>
     