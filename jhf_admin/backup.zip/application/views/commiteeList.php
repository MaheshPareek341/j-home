<?php include("common/header.php"); ?>


      <main id="main" class="main">
         <div class="pagetitle">
            <h1>Commitee Members</h1>
            <nav>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?=base_url()?>cmsadmin/dashboard"">Home</a></li>
                  <li class="breadcrumb-item active">Commitee Members</li>
               </ol>
            </nav>
         </div>
         <!-- End Page Title --> 
         <section class="section dashboard">
             
                <?php if ($this->session->flashdata('message')): ?>
                    <div class="alert <?= $this->session->flashdata('message_type') === 'success' ? 'alert-success' : 'alert-danger' ?>">
                        <?= $this->session->flashdata('message') ?>
                    </div>
                <?php endif; ?>
                
            <div class="row">
                <div class="col-md-12" style="text-align: right; padding: 20px;">
                 <a type="button" class="btn btn-primary" href="<?= base_url('commitee/add') ?>">Add Commitee Member</a>
                </div>
             
                
                <div class="col-md-12">
                    <div class="my-listing-table-wrapper">
                        <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade active show" id="active" role="tabpanel" aria-labelledby="active-tab">
                    
                    
                <div class="recent-listing-area">
                        <div class="recent-listing-table">
                            <table class="eg-table2" id="example">
                                <thead>
                                    <tr>
                                     <th>Image</th>
                                     <th>Name</th>
                                     <th>Members Type</th>
                                     <th>Place</th>
                                     <th>Designation</th>
                                      
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($commitee){
                                        foreach($commitee as $comm){
                                            ?>
                                            <tr>
                                             <td><?php
                                                if(!empty($comm->image)){
                                                    ?>
                                                    <img src="../images/committee/<?=$comm->image?>" width="50"/>
                                                    <?php
                                                }
                                             ?></td>
                                                <td><?=$comm->name?></td>
                                                <td><?=$comm->members_type?></td>
                                                <td><?=$comm->place?></td>
                                               <td><?=$comm->designation?></td>
                                                
                                               <td>
                                                   <a href="<?= base_url('commitee/edit/' . $comm->id) ?>" > <i class="fa fa-edit" style="font-size:22px; cursor: pointer;"></i> </a>
                                                    <sapn style="padding-left:20px;"></sapn> 
                                                    <a href="<?= base_url('commitee/delete/' . $comm->id) ?>" 
                                                       class="btn btn-danger" 
                                                       onclick="return confirm('Are you sure you want to delete this commitee member?')">
                                                    <i class="fa fa-trash" style="font-size:22px"></i></a>
                                                    
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                 </div>
                    </div>
                </div>
            </div>
         </section>
      </main>
     
        
        
        
       
        
        
    </div>

      <script  type="text/javascript">
     
     $(document).ready( function () {
          $('#example').dataTable();
        } );
    
    
</script>
<?php include("common/footer.php"); ?>
     