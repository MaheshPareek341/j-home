<?php include("common/header.php"); ?>


      <main id="main" class="main">
         <div class="pagetitle">
            <h1>Trustees</h1>
            <nav>
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?=base_url()?>dashboard">Home</a></li>
                  <li class="breadcrumb-item active"><a href="<?=base_url()?>trustees">Trustees</a></li>
                  <li class="breadcrumb-item active">Add</li>
               </ol>
            </nav>
         </div>
         <!-- End Page Title --> 
         <section class="section dashboard">

                <?php if ($this->session->flashdata('message')): ?>
                    <div class="alert <?= $this->session->flashdata('message_type') === 'success' ? 'alert-success' : 'alert-danger' ?>">
                        <?= $this->session->flashdata('message') ?>
                    </div>
                <?php endif; ?>
                
            <div class="row">
               
                <div class="col-md-12">
                    <div class="my-listing-table-wrapper">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade active show" id="active" role="tabpanel" aria-labelledby="active-tab">
                    
                                <form action="<?= base_url('trustees/save'); ?>" method="post" enctype="multipart/form-data">
                                     <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control mt-1" id="name" name="name" value="" required>
                                    </div>
                                    
                                     <div class="form-group">
                                        <label for="image">Image</label>
                                        <input type="file" name="image" />
                                    </div>
                                    
                                     <div class="form-group">
                                        <label for="members_type">Father Name</label>
                                        <input type="text" class="form-control mt-1" id="father_name" name="father_name" value="">
                                    </div>
                                    
                                     <div class="form-group">
                                        <label for="place">DOB</label>
                                        <input type="date" class="form-control mt-1" id="dob" name="dob" value="">
                                    </div>
                                    
                                     <div class="form-group">
                                        <label for="designation">Marriage Anniversary</label>
                                        <input type="text" class="form-control mt-1" id="marriage_anniversary" name="marriage_anniversary" value="">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="designation">Mobile Number</label>
                                        <input type="text" class="form-control mt-1" id="mobile_number" name="mobile_number" value="">
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <label for="designation">Email</label>
                                        <input type="email" class="form-control mt-1" id="email" name="email" value="">
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <label for="designation">Address</label>
                                        <input type="text" class="form-control mt-1" id="address" name="address" value="">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="designation">Nominee</label>
                                        <input type="text" class="form-control mt-1" id="nominee" name="nominee" value="">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="designation">Relation</label>
                                        <input type="text" class="form-control mt-1" id="relation" name="relation" value="">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="designation">Designation</label>
                                        <input type="text" class="form-control mt-1" id="designation" name="designation" value="">
                                    </div>
                            
                                   <div class="form-group">
                            <br />
                                    <button type="submit" class="btn btn-primary">Add Trustees</button>
                                    </div>
                                </form>

                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>
      </main>
     
        
        
    </div>

<?php include("common/footer.php"); ?>